/* ============================================================
   GREEN IMMOBILIER — Traductions (fr par défaut, en, ar + RTL)
   Pour ajouter une langue : dupliquer le bloc "en", traduire,
   puis l'ajouter à LANGS dans app.js.
   ============================================================ */
window.I18N = {
  fr: {
    meta: { dir: "ltr", label: "FR", name: "Français" },
    nav: { home: "Accueil", buy: "Acheter", rent: "Louer", holiday: "Location vacances", properties: "Nos biens", about: "À propos", contact: "Contact", submit: "Déposer une annonce", menu: "Menu", close: "Fermer" },
    hero: {
      eyebrow: "Agence immobilière · Hammamet, Tunisie",
      title: "Trouvez le lieu qui vous ressemble.",
      subtitle: "GREEN IMMOBILIER vous accompagne dans tous vos projets immobiliers à Hammamet et partout où vos envies vous mènent.",
      caption: "Villa de prestige de plain-pied, Monchar — Hammamet Sud",
      scroll: "Découvrir"
    },
    search: { buy: "Acheter", rent: "Louer", holiday: "Vacances", type: "Type de bien", anyType: "Tous les types", location: "Localisation", anyLocation: "Toutes les zones", budgetMin: "Budget min.", budgetMax: "Budget max.", any: "Indifférent", submit: "Rechercher" },
    type: { villa: "Villa", appartement: "Appartement", maison: "Maison", terrain: "Terrain", commerce: "Local commercial" },
    typePl: { villa: "Villas", appartement: "Appartements", maison: "Maisons", terrain: "Terrains", commerce: "Commerces" },
    tx: { vente: "À vendre", location: "À louer", vacances: "Location vacances" },
    txShort: { vente: "Vente", location: "Location", vacances: "Vacances" },
    status: { "Disponible": "Disponible", "Vendu": "Vendu", "Loué": "Loué", "Réservé": "Réservé" },
    period: { mois: "/ mois", semaine: "/ semaine", quinzaine: "/ quinzaine" },
    card: { discover: "Découvrir", beds: "ch.", bedsLong: "Chambres", baths: "sdb", bathsLong: "Salles de bain", land: "terrain", living: "habitables", priceOnRequest: "Prix sur demande", photos: "photos" },
    home: {
      introEyebrow: "Green Immobilier",
      introTitle: "Une agence implantée à Hammamet, à vos côtés pour acheter, vendre, louer et passer vos vacances.",
      introText: "Villas avec piscine, appartements, terrains à bâtir ou séjours saisonniers : nous sélectionnons et présentons chaque bien avec soin, et nous vous accompagnons personnellement de la première visite à la remise des clés.",
      s1t: "Vente", s1d: "Villas, appartements et terrains à Hammamet Nord, Hammamet Sud, Zone Théâtre et alentours.",
      s2t: "Location", s2d: "Location à l'année de biens meublés ou non, sélectionnés pour leur emplacement et leur entretien.",
      s3t: "Location vacances", s3d: "Villas et appartements pour vos séjours à la semaine ou à la quinzaine, à proximité des plages.",
      exEyebrow: "Sélection",
      exTitle: "Nos propriétés d'exception",
      exText: "Architecture méditerranéenne, piscines, jardins paysagers : une sélection de villas parmi les plus remarquables de notre portefeuille.",
      exCta: "Découvrir la propriété",
      latestEyebrow: "Annonces",
      latestTitle: "Les biens disponibles",
      latestCta: "Voir tous nos biens",
      catTitle: "Parcourir par catégorie",
      catCount: "biens",
      aboutEyebrow: "Notre approche",
      aboutTitle: "Un accompagnement sur mesure, une connaissance intime de Hammamet.",
      aboutCta: "En savoir plus sur l'agence",
      zonesEyebrow: "Hammamet",
      zonesTitle: "Les quartiers où nous intervenons",
      zonesText: "De la Zone Craxi au nord jusqu'à Monchar et Yasmine Hammamet au sud, nos annonces couvrent les principaux secteurs résidentiels de la ville.",
      ctaTitle: "Vous souhaitez vendre ou louer votre bien ?",
      ctaText: "Confiez-nous votre bien : nous le présentons avec le soin qu'il mérite auprès d'acquéreurs et de locataires qualifiés.",
      ctaBtn: "Déposer une annonce",
      ctaCall: "Appeler l'agence"
    },
    cat: { all: "Tous les biens", villas: "Villas", appartements: "Appartements", maisons: "Maisons", terrains: "Terrains", prestige: "Biens de prestige", saison: "Locations saisonnières" },
    list: {
      title: "Nos biens", titleVente: "Biens à vendre", titleLocation: "Biens à louer", titleVacances: "Locations vacances",
      subtitle: "Toutes les annonces de Green Immobilier à Hammamet et ses environs.",
      filters: "Filtres", transaction: "Transaction", all: "Tous", zone: "Localisation", budget: "Budget (DT)", min: "Min", max: "Max",
      surface: "Surface min. (m²)", bedrooms: "Chambres min.", type: "Type de bien", reset: "Réinitialiser", apply: "Afficher les résultats",
      results: "{n} bien(s)", sort: "Trier", sortRecent: "Plus récents", sortAsc: "Prix croissant", sortDesc: "Prix décroissant", sortSurface: "Surface",
      onlyAvailable: "Biens disponibles uniquement",
      empty: "Aucun bien ne correspond à votre recherche pour le moment.", emptyCta: "Confiez-nous votre recherche"
    },
    prop: {
      back: "Retour aux biens", allPhotos: "Voir les {n} photos", description: "Description", features: "Caractéristiques", amenities: "Équipements & atouts",
      location: "Localisation", mapNote: "Localisation indicative du quartier. L'adresse exacte est communiquée lors de la visite.",
      interested: "Ce bien vous intéresse ?", interestedText: "Notre équipe vous répond rapidement pour toute information ou pour organiser une visite.",
      whatsapp: "WhatsApp", call: "Appeler", similar: "Biens similaires", originalLang: "Description originale en français.",
      transaction: "Transaction", type: "Type", zone: "Quartier", land: "Surface du terrain", living: "Surface habitable", bedrooms: "Chambres", bathrooms: "Salles de bain", ref: "Référence", status: "Statut",
      notFound: "Ce bien est introuvable ou n'est plus en ligne.", share: "Partager", copied: "Lien copié",
      waMsg: "Bonjour Green Immobilier, je suis intéressé(e) par le bien « {title} » ({ref}). "
    },
    form: {
      name: "Nom complet", phone: "Téléphone", email: "E-mail", message: "Message", subject: "Objet",
      send: "Envoyer la demande", required: "Champ obligatoire", invalidEmail: "Adresse e-mail invalide",
      consent: "J'accepte que mes informations soient utilisées pour traiter ma demande.",
      defaultMsg: "Bonjour, je souhaiterais recevoir davantage d'informations sur ce bien et organiser une visite.",
      okTitle: "Votre demande est prête.",
      okText: "Choisissez comment l'envoyer à l'agence : votre message est déjà rédigé.",
      okSent: "Merci ! Votre message a bien été envoyé. L'agence vous recontactera rapidement.",
      viaWa: "Envoyer via WhatsApp", viaMail: "Envoyer par e-mail", error: "L'envoi a échoué. Merci de réessayer ou de nous contacter par téléphone."
    },
    about: {
      title: "À propos de Green Immobilier",
      lead: "Implantée à Hammamet, l'agence Green Immobilier vous accompagne dans l'achat, la vente et la location de votre maison ou de tout autre bien immobilier. Nous sommes également actifs dans le secteur de la location pour vacances.",
      lead2: "Spécialisée dans l'immobilier résidentiel et les villas de standing, l'agence met sa connaissance du terrain au service des propriétaires, des acquéreurs et des locataires.",
      valuesTitle: "Ce qui guide notre travail",
      v1t: "Un accompagnement personnalisé", v1d: "Chaque projet est unique. Nous prenons le temps de comprendre vos attentes, votre budget et votre calendrier, puis nous vous accompagnons à chaque étape.",
      v2t: "L'expertise du marché", v2d: "Estimation, mise en valeur du bien, négociation : nous vous conseillons avec précision pour vendre, acheter ou louer au juste prix.",
      v3t: "La connaissance de Hammamet", v3d: "Hammamet Nord, Zone Théâtre, Monchar, Yasmine Hammamet : nous connaissons chaque quartier, ses atouts et son cadre de vie.",
      v4t: "La disponibilité", v4d: "Joignables par téléphone, WhatsApp et e-mail, nous organisons les visites selon vos disponibilités, y compris à distance.",
      v5t: "La confiance et la transparence", v5d: "Des annonces fidèles, des informations claires sur chaque bien et un suivi honnête, de la première visite à la signature.",
      servicesTitle: "Nos métiers",
      quote: "Experts & spécialistes de l'immobilier de luxe.",
      quoteSrc: "Green Immobilier"
    },
    contact: {
      title: "Contactez l'agence", lead: "Une question, un projet, une visite à organiser ? Écrivez-nous ou appelez-nous directement.",
      address: "Adresse", mobile: "Mobile & WhatsApp", landline: "Téléphone fixe", email: "E-mail", social: "Réseaux sociais",
      formTitle: "Envoyer un message", directions: "Itinéraire", openMaps: "Ouvrir dans Google Maps",
      subjects: { info: "Demande d'information", visit: "Organiser une visite", sell: "Vendre mon bien", rent: "Mettre mon bien en location", other: "Autre" }
    },
    deposit: {
      title: "Déposer une annonce", lead: "Vous souhaitez vendre ou louer votre bien à Hammamet ? Décrivez-le en quelques lignes : nous vous recontactons pour organiser une visite et vous proposer une estimation.",
      propertyTitle: "Votre bien", ownerTitle: "Vos coordonnées", transaction: "Vous souhaitez", sell: "Vendre", rent: "Louer à l'année", holiday: "Louer pour les vacances",
      type: "Type de bien", location: "Localisation (quartier, ville)", surface: "Surface (m²)", rooms: "Nombre de chambres", price: "Prix souhaité (DT)", details: "Description du bien",
      steps: "Comment ça se passe ?", st1: "Vous nous décrivez votre bien", st2: "Nous vous contactons et organisons une visite", st3: "Nous mettons en valeur et diffusons votre annonce",
      send: "Envoyer mon annonce"
    },
    footer: {
      tagline: "Agence immobilière à Hammamet : vente, location et location vacances.",
      explore: "Explorer", agency: "L'agence", contact: "Contact", rights: "Tous droits réservés.", top: "Haut de page"
    },
    amenity: {
      singleLevel: "Plain-pied", infinityPool: "Piscine à débordement", pool: "Piscine privée", garage: "Garage abrité", landscapedGarden: "Jardin paysager",
      garden: "Jardin", suites: "Suites parentales", fireplace: "Cheminée", twoKitchens: "Deux cuisines", borehole: "Forage / sondage privé",
      securedParking: "Parking privé sécurisé", parking: "Parking", panoramicView: "Vue panoramique", solar: "Panneaux photovoltaïques avec batteries",
      ac: "Climatisation", centralHeating: "Chauffage central", titleDeed: "Titre foncier en règle", seaView: "Vue mer", terrace: "Terrasse aménagée",
      balcony: "Balcons privés", outdoorKitchen: "Cuisine extérieure", carport: "Abri voiture", nearAmenities: "Commodités à proximité",
      customFinish: "Finitions au choix", securedSubdivision: "Lotissement sécurisé", twoFrontages: "Deux façades sur route goudronnée",
      furnished: "Meublé", nearBeach: "Proche de la plage", staffStudio: "Studio indépendant"
    }
  },

  en: {
    meta: { dir: "ltr", label: "EN", name: "English" },
    nav: { home: "Home", buy: "Buy", rent: "Rent", holiday: "Holiday rentals", properties: "Properties", about: "About", contact: "Contact", submit: "List your property", menu: "Menu", close: "Close" },
    hero: {
      eyebrow: "Real estate agency · Hammamet, Tunisia",
      title: "Find the place that feels like you.",
      subtitle: "GREEN IMMOBILIER supports you in every property project in Hammamet, and wherever your plans take you.",
      caption: "Single-storey prestige villa, Monchar — Hammamet South",
      scroll: "Explore"
    },
    search: { buy: "Buy", rent: "Rent", holiday: "Holiday", type: "Property type", anyType: "All types", location: "Location", anyLocation: "All areas", budgetMin: "Min. budget", budgetMax: "Max. budget", any: "Any", submit: "Search" },
    type: { villa: "Villa", appartement: "Apartment", maison: "House", terrain: "Land", commerce: "Commercial" },
    typePl: { villa: "Villas", appartement: "Apartments", maison: "Houses", terrain: "Land", commerce: "Commercial" },
    tx: { vente: "For sale", location: "For rent", vacances: "Holiday rental" },
    txShort: { vente: "Sale", location: "Rent", vacances: "Holiday" },
    status: { "Disponible": "Available", "Vendu": "Sold", "Loué": "Rented", "Réservé": "Reserved" },
    period: { mois: "/ month", semaine: "/ week", quinzaine: "/ fortnight" },
    card: { discover: "Discover", beds: "bd", bedsLong: "Bedrooms", baths: "ba", bathsLong: "Bathrooms", land: "plot", living: "living", priceOnRequest: "Price on request", photos: "photos" },
    home: {
      introEyebrow: "Green Immobilier",
      introTitle: "An agency rooted in Hammamet, by your side to buy, sell, rent and holiday.",
      introText: "Villas with pools, apartments, building plots or seasonal stays: we select and present every property with care, and support you personally from the first viewing to the handover of keys.",
      s1t: "Sales", s1d: "Villas, apartments and plots in Hammamet North, Hammamet South, the Théâtre district and surroundings.",
      s2t: "Rentals", s2d: "Long-term rentals, furnished or unfurnished, chosen for their location and upkeep.",
      s3t: "Holiday rentals", s3d: "Villas and apartments for weekly or fortnightly stays, close to the beaches.",
      exEyebrow: "Selection",
      exTitle: "Our exceptional properties",
      exText: "Mediterranean architecture, pools, landscaped gardens: a selection of the most remarkable villas in our portfolio.",
      exCta: "Discover the property",
      latestEyebrow: "Listings",
      latestTitle: "Available properties",
      latestCta: "View all properties",
      catTitle: "Browse by category",
      catCount: "properties",
      aboutEyebrow: "Our approach",
      aboutTitle: "Tailored guidance and an intimate knowledge of Hammamet.",
      aboutCta: "More about the agency",
      zonesEyebrow: "Hammamet",
      zonesTitle: "The neighbourhoods we cover",
      zonesText: "From the Craxi area in the north to Monchar and Yasmine Hammamet in the south, our listings cover the town's main residential areas.",
      ctaTitle: "Would you like to sell or rent your property?",
      ctaText: "Entrust us with your property: we present it with the care it deserves to qualified buyers and tenants.",
      ctaBtn: "List your property",
      ctaCall: "Call the agency"
    },
    cat: { all: "All properties", villas: "Villas", appartements: "Apartments", maisons: "Houses", terrains: "Land", prestige: "Prestige properties", saison: "Seasonal rentals" },
    list: {
      title: "Our properties", titleVente: "Properties for sale", titleLocation: "Properties for rent", titleVacances: "Holiday rentals",
      subtitle: "All Green Immobilier listings in Hammamet and the surrounding area.",
      filters: "Filters", transaction: "Transaction", all: "All", zone: "Location", budget: "Budget (TND)", min: "Min", max: "Max",
      surface: "Min. area (m²)", bedrooms: "Min. bedrooms", type: "Property type", reset: "Reset", apply: "Show results",
      results: "{n} property(ies)", sort: "Sort", sortRecent: "Newest", sortAsc: "Price: low to high", sortDesc: "Price: high to low", sortSurface: "Area",
      onlyAvailable: "Available properties only",
      empty: "No property matches your search at the moment.", emptyCta: "Tell us what you are looking for"
    },
    prop: {
      back: "Back to properties", allPhotos: "View all {n} photos", description: "Description", features: "Key facts", amenities: "Features & highlights",
      location: "Location", mapNote: "Approximate neighbourhood location. The exact address is shared at the viewing.",
      interested: "Interested in this property?", interestedText: "Our team will get back to you quickly with information or to arrange a viewing.",
      whatsapp: "WhatsApp", call: "Call", similar: "Similar properties", originalLang: "Original description in French.",
      transaction: "Transaction", type: "Type", zone: "Area", land: "Plot size", living: "Living area", bedrooms: "Bedrooms", bathrooms: "Bathrooms", ref: "Reference", status: "Status",
      notFound: "This property cannot be found or is no longer online.", share: "Share", copied: "Link copied",
      waMsg: "Hello Green Immobilier, I am interested in the property “{title}” ({ref}). "
    },
    form: {
      name: "Full name", phone: "Phone", email: "Email", message: "Message", subject: "Subject",
      send: "Send request", required: "Required field", invalidEmail: "Invalid email address",
      consent: "I agree that my information may be used to process my request.",
      defaultMsg: "Hello, I would like more information about this property and to arrange a viewing.",
      okTitle: "Your request is ready.",
      okText: "Choose how to send it to the agency: your message is already written.",
      okSent: "Thank you! Your message has been sent. The agency will contact you shortly.",
      viaWa: "Send via WhatsApp", viaMail: "Send by email", error: "Sending failed. Please try again or call us."
    },
    about: {
      title: "About Green Immobilier",
      lead: "Based in Hammamet, Green Immobilier supports you in buying, selling and renting your home or any other property. We are also active in holiday rentals.",
      lead2: "Specialised in residential property and high-end villas, the agency puts its local knowledge at the service of owners, buyers and tenants.",
      valuesTitle: "What guides our work",
      v1t: "Personal guidance", v1d: "Every project is unique. We take the time to understand your expectations, budget and timing, then support you at every step.",
      v2t: "Market expertise", v2d: "Valuation, presentation, negotiation: precise advice to sell, buy or rent at the right price.",
      v3t: "Knowledge of Hammamet", v3d: "Hammamet North, the Théâtre district, Monchar, Yasmine Hammamet: we know each neighbourhood, its strengths and its way of life.",
      v4t: "Availability", v4d: "Reachable by phone, WhatsApp and email, we arrange viewings around your schedule, including remotely.",
      v5t: "Trust and transparency", v5d: "Faithful listings, clear information on every property and honest follow-up, from the first viewing to signing.",
      servicesTitle: "What we do",
      quote: "Experts & specialists in luxury real estate.",
      quoteSrc: "Green Immobilier"
    },
    contact: {
      title: "Contact the agency", lead: "A question, a project, a viewing to arrange? Write to us or call us directly.",
      address: "Address", mobile: "Mobile & WhatsApp", landline: "Landline", email: "Email", social: "Social media",
      formTitle: "Send a message", directions: "Directions", openMaps: "Open in Google Maps",
      subjects: { info: "Information request", visit: "Arrange a viewing", sell: "Sell my property", rent: "Rent out my property", other: "Other" }
    },
    deposit: {
      title: "List your property", lead: "Would you like to sell or rent your property in Hammamet? Describe it in a few lines: we will contact you to arrange a visit and offer a valuation.",
      propertyTitle: "Your property", ownerTitle: "Your details", transaction: "You would like to", sell: "Sell", rent: "Rent long-term", holiday: "Rent for holidays",
      type: "Property type", location: "Location (area, town)", surface: "Area (m²)", rooms: "Bedrooms", price: "Asking price (TND)", details: "Property description",
      steps: "How it works", st1: "You describe your property", st2: "We contact you and arrange a visit", st3: "We showcase and publish your listing",
      send: "Send my listing"
    },
    footer: {
      tagline: "Real estate agency in Hammamet: sales, rentals and holiday rentals.",
      explore: "Explore", agency: "The agency", contact: "Contact", rights: "All rights reserved.", top: "Back to top"
    },
    amenity: {
      singleLevel: "Single storey", infinityPool: "Infinity pool", pool: "Private pool", garage: "Covered garage", landscapedGarden: "Landscaped garden",
      garden: "Garden", suites: "En-suite bedrooms", fireplace: "Fireplace", twoKitchens: "Two kitchens", borehole: "Private borehole",
      securedParking: "Secure private parking", parking: "Parking", panoramicView: "Panoramic view", solar: "Solar panels with batteries",
      ac: "Air conditioning", centralHeating: "Central heating", titleDeed: "Clear land title", seaView: "Sea view", terrace: "Furnished terrace",
      balcony: "Private balconies", outdoorKitchen: "Outdoor kitchen", carport: "Carport", nearAmenities: "Close to amenities",
      customFinish: "Choose your finishes", securedSubdivision: "Secure subdivision", twoFrontages: "Two frontages on paved road",
      furnished: "Furnished", nearBeach: "Close to the beach", staffStudio: "Separate studio"
    }
  },

  ar: {
    meta: { dir: "rtl", label: "ع", name: "العربية" },
    nav: { home: "الرئيسية", buy: "شراء", rent: "كراء", holiday: "كراء العطل", properties: "عقاراتنا", about: "من نحن", contact: "اتصل بنا", submit: "أضف إعلانك", menu: "القائمة", close: "إغلاق" },
    hero: {
      eyebrow: "وكالة عقارية · الحمامات، تونس",
      title: "اعثر على المكان الذي يشبهك.",
      subtitle: "ترافقكم GREEN IMMOBILIER في جميع مشاريعكم العقارية في الحمامات وحيثما تأخذكم رغباتكم.",
      caption: "فيلا فاخرة من طابق واحد، منشار — الحمامات الجنوبية",
      scroll: "اكتشف"
    },
    search: { buy: "شراء", rent: "كراء", holiday: "عطل", type: "نوع العقار", anyType: "كل الأنواع", location: "الموقع", anyLocation: "كل المناطق", budgetMin: "الميزانية الدنيا", budgetMax: "الميزانية القصوى", any: "غير محدد", submit: "بحث" },
    type: { villa: "فيلا", appartement: "شقة", maison: "منزل", terrain: "أرض", commerce: "محل تجاري" },
    typePl: { villa: "فيلات", appartement: "شقق", maison: "منازل", terrain: "أراضٍ", commerce: "محلات تجارية" },
    tx: { vente: "للبيع", location: "للكراء", vacances: "كراء للعطل" },
    txShort: { vente: "بيع", location: "كراء", vacances: "عطل" },
    status: { "Disponible": "متاح", "Vendu": "تم البيع", "Loué": "تم الكراء", "Réservé": "محجوز" },
    period: { mois: "/ شهريًا", semaine: "/ أسبوعيًا", quinzaine: "/ لكل 15 يومًا" },
    card: { discover: "اكتشف", beds: "غرف", bedsLong: "غرف النوم", baths: "حمام", bathsLong: "الحمامات", land: "أرض", living: "مبني", priceOnRequest: "السعر عند الطلب", photos: "صور" },
    home: {
      introEyebrow: "Green Immobilier",
      introTitle: "وكالة متجذّرة في الحمامات، إلى جانبكم للشراء والبيع والكراء وقضاء العطل.",
      introText: "فيلات بمسابح، شقق، أراضٍ للبناء أو إقامات موسمية: نختار كل عقار ونعرضه بعناية، ونرافقكم شخصيًا من أول زيارة حتى تسليم المفاتيح.",
      s1t: "البيع", s1d: "فيلات وشقق وأراضٍ في الحمامات الشمالية والجنوبية ومنطقة المسرح وما حولها.",
      s2t: "الكراء", s2d: "كراء سنوي لعقارات مفروشة أو غير مفروشة، مختارة لموقعها وحسن صيانتها.",
      s3t: "كراء العطل", s3d: "فيلات وشقق لإقامات أسبوعية أو نصف شهرية قرب الشواطئ.",
      exEyebrow: "مختارات",
      exTitle: "عقاراتنا الاستثنائية",
      exText: "عمارة متوسطية، مسابح، حدائق منسّقة: مختارات من أجمل الفيلات في محفظتنا.",
      exCta: "اكتشف العقار",
      latestEyebrow: "الإعلانات",
      latestTitle: "العقارات المتاحة",
      latestCta: "عرض جميع العقارات",
      catTitle: "تصفّح حسب الفئة",
      catCount: "عقارات",
      aboutEyebrow: "نهجنا",
      aboutTitle: "مرافقة مخصّصة ومعرفة عميقة بالحمامات.",
      aboutCta: "المزيد عن الوكالة",
      zonesEyebrow: "الحمامات",
      zonesTitle: "الأحياء التي نعمل فيها",
      zonesText: "من منطقة كراكسي شمالًا إلى منشار وياسمين الحمامات جنوبًا، تغطي إعلاناتنا أهم الأحياء السكنية في المدينة.",
      ctaTitle: "هل ترغبون في بيع عقاركم أو كرائه؟",
      ctaText: "ائتمنونا على عقاركم: نعرضه بالعناية التي يستحقها أمام مشترين ومستأجرين جادّين.",
      ctaBtn: "أضف إعلانك",
      ctaCall: "اتصل بالوكالة"
    },
    cat: { all: "جميع العقارات", villas: "فيلات", appartements: "شقق", maisons: "منازل", terrains: "أراضٍ", prestige: "عقارات فاخرة", saison: "كراء موسمي" },
    list: {
      title: "عقاراتنا", titleVente: "عقارات للبيع", titleLocation: "عقارات للكراء", titleVacances: "كراء العطل",
      subtitle: "جميع إعلانات Green Immobilier في الحمامات وضواحيها.",
      filters: "التصفية", transaction: "نوع المعاملة", all: "الكل", zone: "الموقع", budget: "الميزانية (د.ت)", min: "الأدنى", max: "الأقصى",
      surface: "المساحة الدنيا (م²)", bedrooms: "عدد الغرف الأدنى", type: "نوع العقار", reset: "إعادة الضبط", apply: "عرض النتائج",
      results: "{n} عقار", sort: "ترتيب", sortRecent: "الأحدث", sortAsc: "السعر تصاعديًا", sortDesc: "السعر تنازليًا", sortSurface: "المساحة",
      onlyAvailable: "العقارات المتاحة فقط",
      empty: "لا يوجد حاليًا عقار يطابق بحثكم.", emptyCta: "أخبرونا بما تبحثون عنه"
    },
    prop: {
      back: "العودة إلى العقارات", allPhotos: "عرض الصور ({n})", description: "الوصف", features: "الخصائص", amenities: "التجهيزات والمزايا",
      location: "الموقع", mapNote: "موقع تقريبي للحي. يُقدَّم العنوان الدقيق عند الزيارة.",
      interested: "هل يهمّكم هذا العقار؟", interestedText: "يرد فريقنا عليكم بسرعة لتقديم المعلومات أو لتنظيم زيارة.",
      whatsapp: "واتساب", call: "اتصال", similar: "عقارات مشابهة", originalLang: "الوصف الأصلي باللغة الفرنسية.",
      transaction: "المعاملة", type: "النوع", zone: "الحي", land: "مساحة الأرض", living: "المساحة المبنية", bedrooms: "غرف النوم", bathrooms: "الحمامات", ref: "المرجع", status: "الحالة",
      notFound: "هذا العقار غير موجود أو لم يعد معروضًا.", share: "مشاركة", copied: "تم نسخ الرابط",
      waMsg: "مرحبًا Green Immobilier، أنا مهتم(ة) بالعقار «{title}» ({ref}). "
    },
    form: {
      name: "الاسم الكامل", phone: "الهاتف", email: "البريد الإلكتروني", message: "الرسالة", subject: "الموضوع",
      send: "إرسال الطلب", required: "حقل إلزامي", invalidEmail: "بريد إلكتروني غير صالح",
      consent: "أوافق على استخدام معلوماتي لمعالجة طلبي.",
      defaultMsg: "مرحبًا، أرغب في الحصول على مزيد من المعلومات حول هذا العقار وتنظيم زيارة.",
      okTitle: "طلبكم جاهز.",
      okText: "اختاروا طريقة إرساله إلى الوكالة: رسالتكم مكتوبة مسبقًا.",
      okSent: "شكرًا! تم إرسال رسالتكم وستتصل بكم الوكالة قريبًا.",
      viaWa: "إرسال عبر واتساب", viaMail: "إرسال بالبريد الإلكتروني", error: "تعذّر الإرسال. يرجى المحاولة مجددًا أو الاتصال بنا هاتفيًا."
    },
    about: {
      title: "عن Green Immobilier",
      lead: "تتواجد وكالة Green Immobilier في الحمامات، وترافقكم في شراء منزلكم أو أي عقار آخر وبيعه وكرائه. كما نعمل أيضًا في مجال الكراء للعطل.",
      lead2: "تختص الوكالة في العقارات السكنية والفيلات الراقية، وتضع معرفتها بالميدان في خدمة المالكين والمشترين والمستأجرين.",
      valuesTitle: "ما يوجّه عملنا",
      v1t: "مرافقة شخصية", v1d: "كل مشروع فريد. نأخذ الوقت لفهم توقعاتكم وميزانيتكم وجدولكم الزمني، ثم نرافقكم في كل مرحلة.",
      v2t: "خبرة بالسوق", v2d: "تقييم، إبراز للعقار، تفاوض: نصائح دقيقة للبيع أو الشراء أو الكراء بالسعر المناسب.",
      v3t: "معرفة الحمامات", v3d: "الحمامات الشمالية، منطقة المسرح، منشار، ياسمين الحمامات: نعرف كل حي ومزاياه وأسلوب الحياة فيه.",
      v4t: "التوفّر", v4d: "متاحون عبر الهاتف وواتساب والبريد الإلكتروني، وننظّم الزيارات حسب أوقاتكم، بما في ذلك عن بُعد.",
      v5t: "الثقة والشفافية", v5d: "إعلانات صادقة، معلومات واضحة عن كل عقار ومتابعة نزيهة من أول زيارة حتى التوقيع.",
      servicesTitle: "مجالات عملنا",
      quote: "خبراء ومتخصصون في العقارات الفاخرة.",
      quoteSrc: "Green Immobilier"
    },
    contact: {
      title: "اتصلوا بالوكالة", lead: "سؤال، مشروع، زيارة تودّون تنظيمها؟ راسلونا أو اتصلوا بنا مباشرة.",
      address: "العنوان", mobile: "الجوال وواتساب", landline: "الهاتف القار", email: "البريد الإلكتروني", social: "شبكات التواصل",
      formTitle: "أرسلوا رسالة", directions: "الاتجاهات", openMaps: "فتح في خرائط Google",
      subjects: { info: "طلب معلومات", visit: "تنظيم زيارة", sell: "بيع عقاري", rent: "كراء عقاري", other: "أخرى" }
    },
    deposit: {
      title: "أضف إعلانك", lead: "هل ترغبون في بيع أو كراء عقاركم في الحمامات؟ صفوه في بضعة أسطر وسنتصل بكم لتنظيم زيارة واقتراح تقييم.",
      propertyTitle: "عقاركم", ownerTitle: "بياناتكم", transaction: "ترغبون في", sell: "البيع", rent: "الكراء السنوي", holiday: "الكراء للعطل",
      type: "نوع العقار", location: "الموقع (الحي، المدينة)", surface: "المساحة (م²)", rooms: "عدد الغرف", price: "السعر المطلوب (د.ت)", details: "وصف العقار",
      steps: "كيف تتم العملية؟", st1: "تصفون لنا عقاركم", st2: "نتصل بكم وننظّم زيارة", st3: "نبرز إعلانكم وننشره",
      send: "إرسال إعلاني"
    },
    footer: {
      tagline: "وكالة عقارية في الحمامات: بيع، كراء وكراء للعطل.",
      explore: "تصفّح", agency: "الوكالة", contact: "اتصل بنا", rights: "جميع الحقوق محفوظة.", top: "أعلى الصفحة"
    },
    amenity: {
      singleLevel: "طابق واحد", infinityPool: "مسبح لا متناهي", pool: "مسبح خاص", garage: "مرآب مغطى", landscapedGarden: "حديقة منسّقة",
      garden: "حديقة", suites: "أجنحة رئيسية", fireplace: "مدفأة", twoKitchens: "مطبخان", borehole: "بئر خاصة",
      securedParking: "موقف سيارات خاص ومؤمّن", parking: "موقف سيارات", panoramicView: "إطلالة بانورامية", solar: "ألواح شمسية مع بطاريات",
      ac: "تكييف", centralHeating: "تدفئة مركزية", titleDeed: "رسم عقاري سليم", seaView: "إطلالة على البحر", terrace: "شرفة مجهزة",
      balcony: "شرفات خاصة", outdoorKitchen: "مطبخ خارجي", carport: "مأوى سيارة", nearAmenities: "قرب المرافق",
      customFinish: "تشطيبات حسب الاختيار", securedSubdivision: "تقسيم مؤمّن", twoFrontages: "واجهتان على طريق معبّد",
      furnished: "مفروش", nearBeach: "قرب الشاطئ", staffStudio: "استوديو مستقل"
    }
  }
};
