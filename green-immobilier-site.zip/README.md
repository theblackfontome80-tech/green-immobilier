# Green Immobilier — Site web

Site vitrine et catalogue immobilier pour **Green Immobilier** (Hammamet, Tunisie).
HTML / CSS / JavaScript sans dépendance ni étape de build : il suffit de déposer le dossier sur n'importe quel hébergement statique (OVH, Netlify, Vercel, GitHub Pages, cPanel…).

## Pages

| Fichier | Contenu |
|---|---|
| `index.html` | Accueil : hero + moteur de recherche, services, « Nos propriétés d'exception », biens disponibles, catégories, approche, quartiers, appel à l'action |
| `biens.html` | Catalogue : catégories, filtres (transaction, type, zone, budget, surface, chambres, disponibilité), tri. Les filtres sont repris dans l'URL (`biens.html?t=vente&zone=hammamet-nord&max=1000000`) |
| `bien.html?id=…` | Fiche d'un bien : galerie plein écran (clavier + glissé tactile), description, caractéristiques, équipements, carte, formulaire, WhatsApp, appel |
| `a-propos.html` | Présentation de l'agence |
| `contact.html` | Coordonnées, formulaire, carte Google Maps |
| `deposer.html` | Formulaire « Déposer une annonce » pour les propriétaires |

## Gérer les annonces

Toutes les annonces sont dans **`assets/js/listings.js`** (un bloc `{ … }` par bien, champs documentés en tête du fichier).

- **Ajouter** : copier un bloc existant, changer l'`id` (unique), les textes, le prix et les photos.
- **Modifier** : éditer les champs (ex. `"status": "Vendu"`).
- **Supprimer** : retirer le bloc.
- **Mettre en avant** dans « Nos propriétés d'exception » : `"prestige": true` (vente + disponible).

Les catégories, compteurs, filtres, pages individuelles et le plan du site s'adaptent automatiquement.
Pour régénérer `sitemap.xml`, mettre à jour la liste des URL `bien.html?id=…`.

## Langues

Français (par défaut), anglais et arabe (affichage RTL complet). Sélecteur dans l'en-tête ; la langue est mémorisée et transmise dans les liens (`?lang=en`, `?lang=ar`).
Textes de l'interface : `assets/js/i18n.js`. Les descriptions d'annonces restent en français (texte d'origine) ; un titre traduit est prévu pour chaque bien.

## Formulaires

Par défaut, chaque formulaire est validé puis le message, déjà rédigé, est proposé à l'envoi **par WhatsApp** (+216 98 100 513) ou **par e-mail**.
Pour recevoir les demandes directement, créer un formulaire sur un service comme Formspree ou Getform, puis renseigner son URL dans `assets/js/app.js` :

```js
formEndpoint: "https://formspree.io/f/xxxxxxx"
```

## Coordonnées de l'agence

Centralisées dans `assets/js/app.js` (objet `AGENCY`). Sources : site greenimmobiliere.tn, profil Instagram @green_immobilier, fiche Google Maps.

## À prévoir avant la mise en ligne

1. **Photos** : elles sont hébergées dans le site au format WebP (`assets/img/biens/<référence>/01.webp` + vignette `01-sm.webp`) et portent le filigrane de l'agence. Pour un rendu optimal, les remplacer par les originaux sans filigrane, en gardant les mêmes noms de fichiers.
2. **Adresse** : seule la mention « 8050 Hammamet, Tunisie » et le repère Google Maps sont publics ; ajouter la rue si l'agence le souhaite.
3. **Horaires d'ouverture** : non publiés, donc non affichés.
4. **E-mail** : `contact@greenimmobiliere.com` est l'adresse indiquée sur le site actuel ; vérifier qu'elle reçoit bien les messages.
5. **Domaine** : remplacer `https://www.greenimmobiliere.tn/` dans les balises canonical / sitemap si le site est publié ailleurs.
6. **Locations et locations vacances** : sur le site actuel, ces annonces sont marquées « Loué ». Elles sont présentées comme telles ; passer `status` à `"Disponible"` lorsqu'un bien est de nouveau proposé.

## Tester en local

Ouvrir le dossier avec un petit serveur, par exemple :

```
npx serve .
```

puis aller sur http://localhost:3000.
