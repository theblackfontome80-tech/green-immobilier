/* ============================================================
   GREEN IMMOBILIER — Catalogue des annonces
   ------------------------------------------------------------
   Données issues des annonces publiées par l'agence sur
   greenimmobiliere.tn (relevé du 23/11/2026).

   Ajouter une annonce : copier un bloc { ... } et modifier ses champs.
   Supprimer : retirer le bloc. Modifier : éditer les champs.

   Champs :
   id           identifiant unique utilisé dans l'URL (bien.html?id=...)
   status       "Disponible" | "Vendu" | "Loué" | "Réservé"
   transaction  "vente" | "location" | "vacances"
   type         "villa" | "appartement" | "maison" | "terrain" | "commerce"
   prestige     true → apparaît dans « Nos propriétés d'exception »
   zone         clé de quartier (voir ZONES ci-dessous)
   place        localisation affichée
   title        { fr, en, ar }
   price        nombre en DT (null = prix sur demande)
   pricePeriod  null | "mois" | "semaine" | "quinzaine" | texte libre
   landArea / livingArea  m² (null si non communiqué)
   bedrooms / bathrooms   nombre (null si non communiqué)
   amenities    clés traduites dans i18n.js (section "amenity")
   description  paragraphes (texte original de l'annonce)
   photos       fichiers WebP relatifs à IMG_BASE (ex. "139228/01.webp").
                La vignette correspondante se nomme "01-sm.webp" (même dossier).
   source       annonce d'origine
   ============================================================ */

window.IMG_BASE = "assets/img/biens/";

window.ZONES = {
  "hammamet":        { fr: "Hammamet",         en: "Hammamet",             ar: "الحمامات",         map: "Hammamet, Tunisie" },
  "hammamet-nord":   { fr: "Hammamet Nord",    en: "Hammamet North",       ar: "الحمامات الشمالية", map: "Hammamet Nord, Tunisie" },
  "hammamet-sud":    { fr: "Hammamet Sud",     en: "Hammamet South",       ar: "الحمامات الجنوبية", map: "Hammamet Sud, Tunisie" },
  "hammamet-centre": { fr: "Hammamet centre",  en: "Hammamet town centre", ar: "وسط الحمامات",     map: "Médina de Hammamet, Tunisie" },
  "zone-theatre":    { fr: "Zone Théâtre",     en: "Théâtre district",     ar: "منطقة المسرح",     map: "Centre Culturel International de Hammamet, Tunisie" },
  "yasmine":         { fr: "Zone touristique", en: "Tourist zone",         ar: "المنطقة السياحية",  map: "Zone touristique Hammamet Sud, Tunisie" }
};

window.LISTINGS = [
  {
    "id": "139228-villa-da-nang",
    "ref": "Ref304a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": true,
    "zone": "hammamet",
    "place": "Hammamet — à 10 min de Yasmine Hammamet",
    "title": {
      "fr": "Villa « Da Nang »",
      "en": "Villa “Da Nang”",
      "ar": "فيلا «دا نانغ»"
    },
    "price": 890000,
    "pricePeriod": null,
    "landArea": 474,
    "livingArea": 254,
    "bedrooms": 3,
    "bathrooms": null,
    "amenities": [
      "singleLevel",
      "infinityPool",
      "garage",
      "landscapedGarden",
      "suites"
    ],
    "description": [
      "Villa de luxe d'exception à Hammamet",
      "Découvrez cette magnifique villa de plain-pied située à Hammamet, à seulement 10 minutes du cœur de Yasmine Hammamet.",
      "Érigée sur un terrain de 474 m², cette propriété offre une surface habitable de 254 m² alliant confort moderne et finitions de haute qualité.",
      "L'aménagement extérieur, véritable atout de ce bien, est pensé pour offrir un cadre de vie privilégié, propice à la détente et à la relaxation dans un environnement verdoyant.",
      "L'intérieur se distingue par une conception soignée et une décoration raffinée.",
      "La villa dispose d'une configuration en S+3, incluant trois suites spacieuses garantissant une intimité totale.",
      "L'espace extérieur est sublimé par une piscine à débordement et un garage abrité, complétant ainsi les prestations haut de gamme de cette demeure.",
      "Une opportunité rare sur le marché pour les amateurs de confort et d'élégance. Villa de plain-pied d'une surface habitable de 254 m²",
      "Configuration en S+3 avec trois suites",
      "Terrain paysager de 474 m²",
      "Piscine à débordement",
      "Garage abrité",
      "Contactez-nous dès aujourd'hui pour organiser une visite de cette villa d'exception."
    ],
    "photos": [
      "139228/01.webp",
      "139228/02.webp",
      "139228/03.webp",
      "139228/04.webp",
      "139228/05.webp",
      "139228/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/139228"
  },
  {
    "id": "140792-villa-arabesque-s5-double-hauteur",
    "ref": "Ref309a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": true,
    "zone": "hammamet",
    "place": "Hammamet — à 5 min de Yasmine Hammamet",
    "title": {
      "fr": "Villa Arabesque S+5 à double hauteur",
      "en": "Arabesque Villa, 5 bedrooms, double-height living",
      "ar": "فيلا عربية الطراز S+5 بسقف مزدوج الارتفاع"
    },
    "price": 1350000,
    "pricePeriod": null,
    "landArea": 665,
    "livingArea": 300,
    "bedrooms": 5,
    "bathrooms": null,
    "amenities": [
      "pool",
      "landscapedGarden",
      "fireplace",
      "twoKitchens",
      "borehole",
      "securedParking"
    ],
    "description": [
      "Splendide Villa de Luxe Style Arabesque – S+5 à 5 min de Yasmine Hammamet",
      "Plongez au cœur du raffinement avec cette somptueuse villa d'architecte au style arabesque réinventé, alliant à la perfection le charme de l'authentique et le confort absolu de la modernité.",
      "Érigée sur un terrain généreux de 665 m² avec une surface bâtie de 300 m²,",
      "cette propriété d'exception incarne le grand luxe dans une zone ultra-recherchée et calme, dotée d'un excellent voisinage.",
      "Un design architectural unique et lumineux",
      "Dès l'arrivée, le ton est donné :",
      "Une porte d'entrée géante majestueuse qui s'ouvre sur un espace de vie spectaculaire.",
      "Une double hauteur sous plafond baignée de lumière naturelle grâce à des fenêtres gigantesques offrant des vues imprenables sur l'extérieur.",
      "Un design épuré et contemporain sublimé par un escalier suspendu et une cheminée suspendue en bois, véritable pièce maîtresse chaleureuse et design du salon.",
      "Des espaces de vie pensés pour l'excellence Un grand salon/séjour baigné de lumière, idéal pour recevoir.",
      "Deux cuisines indépendantes de grand standing : une cuisine de préparation fonctionnelle et une cuisine de finition haut de gamme. 5 chambres spacieuses (S+5) agencées pour garantir un confort et une intimité parfaits pour toute la famille.",
      "Un extérieur digne d'un havre de paix",
      "Profitez d'un cadre de vie extérieur privilégié et intimiste : Une superbe piscine entourée de terrasses.",
      "Un jardin paysager orné de magnifiques palmiers, créant une atmosphère de vacances permanente.",
      "Un forage privé garantissant une autonomie totale en eau.",
      "Un parking privé sécurisé.",
      "Localisation idéale Située dans une zone très demandée, à seulement 5 minutes de Yasmine Hammamet, vous bénéficierez de la proximité immédiate de toutes les commodités, des plages et des animations tout en profitant d'un cadre résidentiel paisible et sécurisé.",
      "Une opportunité rare pour les connaisseurs en quête d'exclusivité et de prestige.",
      "Contactez-nous dès aujourd'hui pour organiser une visite privée de cette propriété d'exception."
    ],
    "photos": [
      "140792/01.webp",
      "140792/02.webp",
      "140792/03.webp",
      "140792/04.webp",
      "140792/05.webp",
      "140792/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/140792"
  },
  {
    "id": "140341-villa-prestige-plain-pied-monchar",
    "ref": "Ref307a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": true,
    "zone": "hammamet-sud",
    "place": "Monchar, Hammamet Sud",
    "title": {
      "fr": "Villa de prestige de plain-pied, Monchar",
      "en": "Single-storey prestige villa, Monchar",
      "ar": "فيلا فاخرة من طابق واحد، منشار"
    },
    "price": 840000,
    "pricePeriod": null,
    "landArea": 900,
    "livingArea": 250,
    "bedrooms": 3,
    "bathrooms": 3,
    "amenities": [
      "singleLevel",
      "panoramicView",
      "pool",
      "landscapedGarden",
      "solar",
      "borehole",
      "twoKitchens",
      "parking",
      "suites"
    ],
    "description": [
      "A la recherche d’un havre de paix alliant modernité, confort absolu et sérénité ?",
      "Découvrez cette sublime villa de plain-pied nichée sur les hauteurs verdoyantes de Monchar (Hammamet Sud), au cœur d’un quartier résidentiel exclusif composé uniquement de villas de luxe. Offrant une vue panoramique à couper le souffle,",
      "cette propriété d’exception s’étend sur un vaste terrain de 900 m² avec une surface bâtie de 250 m².",
      "Espaces de vie :",
      "Grand salon baigné de lumière, cuisine américaine de finition moderne + cuisine de préparation indépendante.",
      "Espace nuit :",
      "3 magnifiques suites parentales avec salles de bain privatives.",
      "Extérieurs :",
      "Grand jardin paysager, belle piscine avec cascade d'eau, sondage d'eau privé et parking.",
      "Atout unique : Système photovoltaïque installé avec batteries pour une autonomie énergétique totale même en cas de coupure.",
      "Localisation :Monchar, Hammamet Côté Sud (Tunisie)",
      "Surface Terrain : 900 m² Surface",
      "Bâtie : 250 m²",
      "Chambres : 3 Suites Parentales",
      "Contactez-nous dès aujourd’hui pour organiser une visite et découvrir cette demeure d'exception !"
    ],
    "photos": [
      "140341/01.webp",
      "140341/02.webp",
      "140341/03.webp",
      "140341/04.webp",
      "140341/05.webp",
      "140341/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/140341"
  },
  {
    "id": "139531-villa-elysee-zone-theatre",
    "ref": "Ref306a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": true,
    "zone": "zone-theatre",
    "place": "Zone Théâtre, Hammamet",
    "title": {
      "fr": "Villa « Elysée », Zone Théâtre",
      "en": "Villa “Elysée”, Théâtre district",
      "ar": "فيلا «الإليزيه»، منطقة المسرح"
    },
    "price": 1150000,
    "pricePeriod": null,
    "landArea": 400,
    "livingArea": 280,
    "bedrooms": 4,
    "bathrooms": 4,
    "amenities": [
      "pool",
      "landscapedGarden",
      "parking",
      "ac",
      "centralHeating",
      "suites",
      "titleDeed"
    ],
    "description": [
      "Villa \"Elysée\"",
      "Statut Juridique : Titre Foncier en règle",
      "L'AGENCE GREEN IMMOBILIER vous propose à la vente l'une de ses plus belles exclusivités : la Villa \"Elysée\", située dans le quartier le plus prisé et recherché d'Hammamet,",
      "La Zone Théâtre. Alliant architecture moderne, finitions haut de gamme et intimité absolue,",
      "cette propriété est idéale pour une résidence principale de prestige ou un investissement patrimonial sécurisé en Tunisie.",
      "Caractéristiques principales : Superficie du terrain : 400 m² Surface habitable : 280 m² Espace Nuit : 4 superbes suites parentales (chambre + dressing + salle d'eau privative), offrant un confort optimal à toute la famille ou vos invités.",
      "Espace de Jour : Un vaste salon lumineux baigné de lumière naturelle ouvrant sur les terrasses et le jardin. Cuisine : Moderne, fonctionnelle et entièrement équipée.",
      "xtérieurs & Confort : Piscine privée sans vis-à-vis. Jardin paysagé et clôturé.",
      "Espace parking / abri voitures. Climatisation et chauffage central installés.",
      "Emplacement stratégique : Située dans un environnement calme, résidentiel et haut standing, à proximité immédiate de toutes les commodités de la ville et à quelques minutes des plages d'Hammamet."
    ],
    "photos": [
      "139531/01.webp",
      "139531/02.webp",
      "139531/03.webp",
      "139531/04.webp",
      "139531/05.webp",
      "139531/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/139531"
  },
  {
    "id": "141001-villa-moderne-vue-mer-craxi",
    "ref": "Ref310a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": true,
    "zone": "hammamet-nord",
    "place": "Zone Craxi, Hammamet Nord",
    "title": {
      "fr": "Villa moderne vue mer, 4 suites — Craxi",
      "en": "Modern sea-view villa, 4 suites — Craxi",
      "ar": "فيلا عصرية بإطلالة بحرية، 4 أجنحة — كراكسي"
    },
    "price": 860000,
    "pricePeriod": null,
    "landArea": 200,
    "livingArea": 245,
    "bedrooms": 4,
    "bathrooms": null,
    "amenities": [
      "pool",
      "seaView",
      "terrace",
      "suites"
    ],
    "description": [
      "Emplacement d'exception à Hammamet Nord (Zone Craxi)",
      "Située dans l'un des quartiers résidentiels les plus prisés et calmes d'Hammamet Nord, cette villa contemporaine offre un cadre de vie privilégié à seulement 2 minutes du centre-ville d'Hammamet, des plages et de toutes les commodités.",
      "Caractéristiques principales :",
      "*Surface du terrain : 200 m²",
      "*Surface bâtie : 245 m²",
      "Agencement et prestations :",
      "*Rez-de-chaussée :",
      "Un vaste salon lumineux ouvert sur l'extérieur, une cuisine américaine moderne entièrement aménagée, ainsi qu'une salle d'eau pour les invités.",
      "*Espace nuit :",
      "4 suites parentales spacieuses, offrant chacune confort, intimité et rangements.",
      "*Extérieurs :",
      "Un espace extérieur convivial agrémenté d'une piscine privée, idéal pour profiter du climat méditerranéen.",
      "Le plus : Une magnifique terrasse aménagée offrant une vue dégagée sur la mer.",
      "Les points forts de ce bien :",
      "*Adresse recherchée (Zone Craxi, Hammamet Nord).",
      "*Proximité immédiate du centre-ville (2 min) tout en étant au calme.",
      "*Configuration idéale en 4 suites pour une résidence principale ou un investissement locatif saisonnier à forte rentabilité.",
      "Pour plus d'informations ou pour organiser une visite, n'hésitez pas à nous contacter."
    ],
    "photos": [
      "141001/01.webp",
      "141001/02.webp",
      "141001/03.webp",
      "141001/04.webp",
      "141001/05.webp",
      "141001/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/141001"
  },
  {
    "id": "140599-villa-style-grec-craxi",
    "ref": "Ref308a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet-nord",
    "place": "Zone Craxi, Hammamet Nord",
    "title": {
      "fr": "Villa de style grec avec cheminée — Craxi",
      "en": "Greek-style villa with fireplace — Craxi",
      "ar": "فيلا على الطراز اليوناني مع مدفأة — كراكسي"
    },
    "price": 950000,
    "pricePeriod": null,
    "landArea": 300,
    "livingArea": 250,
    "bedrooms": 4,
    "bathrooms": null,
    "amenities": [
      "fireplace",
      "centralHeating",
      "ac",
      "balcony"
    ],
    "description": [
      "Achetez votre villa de rêve au style grec unique à Hammamet Nord (Zone Craxi)",
      "Découvrez cette magnifique villa au style architectural grec, alliant charme traditionnel et confort moderne, implantée sur un terrain de 300 m² avec une superficie bâtie de 250 m².",
      "Idéalement située dans le secteur très prisé de Craxi à Hammamet Nord,",
      "la propriété bénéficie d'un emplacement stratégique : accès immédiat à la ceinture (1 minute) et à seulement 3 minutes du centre-ville.",
      "Description détaillée du bien :",
      "Au Rez-de-Chaussée :",
      "Espace de vie d’exception :",
      "Un vaste salon lumineux sublimé par de superbes voûtes traditionnelles et une cheminée en bois chaleureuse.",
      "Cuisine moderne entièrement aménagée.",
      "Une chambre à coucher idéale pour des invités ou des seniors.",
      "Une salle d'eau pour invités.",
      "À l'Étage :",
      "Une suite parentale spacieuse et confortable.",
      "2 chambres à coucher lumineuses avec balcon privé.",
      "Équipements & Prestations :",
      "Architecture de style grec avec finitions soignées.",
      "Chauffage central entièrement installé.",
      "Climatiseurs installés dans les pièces principales.",
      "Emplacement calme, accessible et proche de toutes les commodités.",
      "Informations clés :",
      "Surface terrain : 300 m²",
      "Surface bâtie : 250 m²",
      "Localisation : Craxi, Hammamet Nord"
    ],
    "photos": [
      "140599/01.webp",
      "140599/02.webp",
      "140599/03.webp",
      "140599/04.webp",
      "140599/05.webp",
      "140599/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/140599"
  },
  {
    "id": "139356-villa-sapa",
    "ref": "Ref305a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet",
    "place": "Hammamet",
    "title": {
      "fr": "Villa « Sapa »",
      "en": "Villa “Sapa”",
      "ar": "فيلا «سابا»"
    },
    "price": 860000,
    "pricePeriod": null,
    "landArea": 600,
    "livingArea": 316,
    "bedrooms": 4,
    "bathrooms": null,
    "amenities": [
      "pool",
      "outdoorKitchen",
      "carport",
      "suites"
    ],
    "description": [
      "Villa de prestige à Hammamet",
      "Découvrez cette magnifique villa située à Hammamet, offrant un cadre de vie alliant luxe et confort.",
      "Érigée sur un terrain spacieux de 600 m², cette propriété dispose d'une surface habitable de 316 m².",
      "L'agencement intérieur a été pensé pour offrir des espaces généreux et fonctionnels, parfaits pour une résidence principale ou secondaire.",
      "La villa se distingue par ses prestations haut de gamme, incluant trois suites privatives qui garantissent une intimité totale.",
      "L'extérieur est un véritable havre de paix, agrémenté d'une piscine privée et d'une cuisine extérieure, idéale pour vos moments de détente et de convivialité.",
      "Un abri de voiture complète les prestations de ce bien situé dans un quartier calme et sécurisé. Terrain de 600 m² avec 316 m² habitables",
      "Trois suites spacieuses",
      "Piscine privée",
      "Cuisine extérieure aménagée",
      "Abri de voiture",
      "Contactez-nous dès aujourd'hui pour organiser une visite de cette villa d'exception."
    ],
    "photos": [
      "139356/01.webp",
      "139356/02.webp",
      "139356/03.webp",
      "139356/04.webp",
      "139356/05.webp",
      "139356/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/139356"
  },
  {
    "id": "141484-villa-s4-piscine-commodites",
    "ref": "Ref313a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet",
    "place": "Hammamet",
    "title": {
      "fr": "Villa S+4 avec piscine, 4 suites",
      "en": "4-suite villa with pool",
      "ar": "فيلا S+4 مع مسبح، 4 أجنحة"
    },
    "price": 720000,
    "pricePeriod": null,
    "landArea": 193,
    "livingArea": 200,
    "bedrooms": 4,
    "bathrooms": 4,
    "amenities": [
      "pool",
      "parking",
      "suites",
      "nearAmenities"
    ],
    "description": [
      "Vous rêvez d’une villa moderne, pratique et idéalement située à Hammamet ?",
      "Ne cherchez plus, ce S+4 coche toutes les cases !",
      "Pensé pour offrir confort et intimité à toute la famille, ce bien bien agencé sur 193 m² de terrain pour 200 m² bâtis séduit dès les premiers instants par son espace de vie lumineux et son extérieur convivial avec piscine.",
      "Les atouts qui font la différence :",
      "-4 suites parentales : chacune dispose de sa propre salle de bain individuelle pour un confort optimal au quotidien.",
      "-Pièce de vie conviviale : un salon accueillant, idéal pour recevoir famille et amis.",
      "-Salle d’eau invités : pratique et bien pensée pour préserver l’intimité de l’espace nuit.",
      "-Extérieur & piscine : profitez des beaux jours au bord de votre piscine privative.",
      "-Stationnement : place de parking dédiée.",
      "-Emplacement ultra-pratique : à proximité immédiate de toutes les commodités accessibles à pied (commerces, services, transports...).",
      "Que ce soit pour une résidence principale, une maison de vacances ou un investissement locatif recherché à Hammamet, cette villa offre un équilibre rare entre confort moderne et vie pratique sans dépendre de la voiture. Contactez-nous dès maintenant pour obtenir plus d’informations ou organiser une visite avant qu’il ne soit trop tard !"
    ],
    "photos": [
      "141484/01.webp",
      "141484/02.webp",
      "141484/03.webp",
      "141484/04.webp",
      "141484/05.webp",
      "141484/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/141484"
  },
  {
    "id": "141483-villa-arabesque-voutes-hammamet-sud",
    "ref": "Ref312a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet-sud",
    "place": "Hammamet Sud",
    "title": {
      "fr": "Villa arabesque à voûtes S+3, à finaliser",
      "en": "Vaulted arabesque villa, 3 bedrooms, to finish",
      "ar": "فيلا عربية بأقواس S+3، قيد الإنجاز"
    },
    "price": 360000,
    "pricePeriod": null,
    "landArea": 569,
    "livingArea": 275,
    "bedrooms": 3,
    "bathrooms": null,
    "amenities": [
      "customFinish"
    ],
    "description": [
      "Coups de cœur assuré pour les amoureux du cachet tunisien et des beaux volumes !",
      "À vendre à Hammamet côté Sud, une belle villa S+3 en cours de finition, offrant un potentiel énorme pour créer la maison de vos rêves ou réaliser un investissement à forte valeur ajoutée.",
      "Superficies :",
      "Terrain : 569 m²",
      "Bâti : 275 m²",
      "Architecture & Agencement : Style arabesque authentique sublimé par de superbes voûtes qui apportent charme, fraîcheur et caractère",
      "Un salon lumineux et convivial",
      "1 suite parentale",
      "2 chambres confortables",
      "Une cuisine à aménager selon vos goûts",
      "Pourquoi cette villa sort du lot ?",
      "Parce qu’elle est inachevée, vous avez la liberté totale de choisir vos finitions (revêtements, menuiserie, cuisine, extérieurs et aménagement du jardin sur 569 m²) tout en partant sur une structure déjà bien dessinée au charme intemporel.",
      "Localisation : Hammamet Sud, un secteur prisé pour son cadre de vie et son attractivité.",
      "Contactez-nous dès maintenant pour plus d’informations, organiser une visite et découvrir tout le potentiel de ce bien !"
    ],
    "photos": [
      "141483/01.webp",
      "141483/02.webp",
      "141483/03.webp",
      "141483/04.webp",
      "141483/05.webp",
      "141483/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/141483"
  },
  {
    "id": "90798-villa-le-petit-prince",
    "ref": "Ref225a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet-sud",
    "place": "Monchar, Hammamet",
    "title": {
      "fr": "Villa « Le Petit Prince »",
      "en": "Villa “Le Petit Prince”",
      "ar": "فيلا «الأمير الصغير»"
    },
    "price": 300000,
    "pricePeriod": null,
    "landArea": 500,
    "livingArea": 90,
    "bedrooms": 2,
    "bathrooms": 1,
    "amenities": [
      "pool",
      "garden"
    ],
    "description": [
      "À vendre chez Green Immobilière, une demeure de prestige située à Hammamet zone monchar",
      "Elle s'étend sur un terrain de 500 m² avec une superficie habitable de 90 m².",
      "La villa offre:",
      "-un salon salle a manger",
      "-Une cuisine haut de gamme , offrant des espaces de rangement intelligents et ergonomiques",
      "-deux chambres a couchers",
      "-une salle de bain",
      "-Un jardin",
      "-une piscine"
    ],
    "photos": [
      "90798/01.webp",
      "90798/02.webp",
      "90798/03.webp",
      "90798/04.webp",
      "90798/05.webp",
      "90798/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/90798"
  },
  {
    "id": "141482-terrains-craxi-hammamet-nord",
    "ref": "Ref311a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "terrain",
    "prestige": false,
    "zone": "hammamet-nord",
    "place": "Zone Craxi, Hammamet Nord",
    "title": {
      "fr": "Terrains en lotissement sécurisé — Craxi",
      "en": "Plots in a secure subdivision — Craxi",
      "ar": "أراضٍ في تقسيم مؤمّن — كراكسي"
    },
    "price": null,
    "pricePeriod": "600 DT / m²",
    "landArea": 664,
    "livingArea": null,
    "bedrooms": null,
    "bathrooms": null,
    "amenities": [
      "securedSubdivision"
    ],
    "description": [
      "Vous rêvez de bâtir votre future villa ou de réaliser un investissement sûr dans l’un des secteurs les plus recherchés de Hammamet ?",
      "Découvrez ce lotissement sécurisé de 4 lots idéalement situé à Hammamet Nord, zone Craxi, alliant calme, accessibilité et valorisation durable.",
      "Les atouts du projet :",
      "Emplacement privilégié : Hammamet Nord – Zone Craxi, proche des commodités et des axes principaux.",
      "Cadre rassurant : Lotissement sécurisé, idéal pour une résidence principale, secondaire ou un projet patrimonial.",
      "Des superficies équilibrées : Parfaites pour des constructions modernes avec jardin et espace extérieur.",
      "Disponibilité des lots :",
      "Lot N°1 : 652 m² (Vendu)",
      "Lot N°2 : 664 m² (Disponible)",
      "Lot N°3 : 613 m² (Disponible)",
      "Lot N°4 : 626 m² (Disponible)",
      "Les demandes dans ce secteur partent vite — le Lot N°1 a déjà trouvé preneur !",
      "Contactez-nous dès maintenant pour obtenir plus d’informations, organiser une visite sur place ou réserver votre parcelle."
    ],
    "photos": [
      "141482/01.webp",
      "141482/02.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/141482"
  },
  {
    "id": "98180-terrain-le-theatre",
    "ref": "Ref234a",
    "status": "Disponible",
    "transaction": "vente",
    "type": "terrain",
    "prestige": false,
    "zone": "zone-theatre",
    "place": "Zone Théâtre, Hammamet",
    "title": {
      "fr": "Terrain « Le Théâtre »",
      "en": "“Le Théâtre” building plot",
      "ar": "أرض «المسرح»"
    },
    "price": 468000,
    "pricePeriod": null,
    "landArea": 468,
    "livingArea": null,
    "bedrooms": null,
    "bathrooms": null,
    "amenities": [
      "twoFrontages"
    ],
    "description": [
      "À vendre chez Green Immobilière, un terrain de 468 M² à Hammamet zone théâtre municipale Hammamet",
      "Avec deux façades donnant sur une route goudronnée",
      "Ce terrain offre un emplacement stratégique idéal pour la construction d'une villa avec un accès facile aux commodités locales",
      "pour plus d'informations contacter nous sur 00216 98100513"
    ],
    "photos": [
      "98180/01.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/98180"
  },
  {
    "id": "48516-villa-amira",
    "ref": "Ref162a",
    "status": "Loué",
    "transaction": "location",
    "type": "villa",
    "prestige": false,
    "zone": "zone-theatre",
    "place": "Zone Théâtre, Hammamet",
    "title": {
      "fr": "Villa « Amira »",
      "en": "Villa “Amira”",
      "ar": "فيلا «أميرة»"
    },
    "price": 5500,
    "pricePeriod": "mois",
    "landArea": 300,
    "livingArea": 320,
    "bedrooms": 4,
    "bathrooms": 5,
    "amenities": [
      "pool",
      "garden",
      "ac",
      "centralHeating",
      "suites"
    ],
    "description": [
      "À louer chez Green immobilière une villa de charme 2 minutes du théâtre municipal de d'hammamet ,superficie du terrain 300 m², couverte 320 m²",
      "La villa se compose de :",
      "-Un grand salon",
      "-4 suites",
      "-5 salles de bains",
      "-une salle à manger",
      "-un jardin",
      "-une piscine",
      "La villa est équipée de chauffage central et de climatisation.",
      "Prix 5500 DT par mois"
    ],
    "photos": [
      "48516/01.webp",
      "48516/02.webp",
      "48516/03.webp",
      "48516/04.webp",
      "48516/05.webp",
      "48516/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/48516"
  },
  {
    "id": "22448-villa-s2-vincenzo",
    "ref": "Ref98a",
    "status": "Loué",
    "transaction": "location",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet",
    "place": "Hammamet",
    "title": {
      "fr": "Villa S+2 « Vincenzo », meublée",
      "en": "Villa “Vincenzo”, furnished, 2 bedrooms",
      "ar": "فيلا «فينتشنزو» S+2 مفروشة"
    },
    "price": 1600,
    "pricePeriod": null,
    "landArea": 250,
    "livingArea": null,
    "bedrooms": 2,
    "bathrooms": 1,
    "amenities": [
      "furnished",
      "garden"
    ],
    "description": [
      "À louer à l’année chez Green immobilière une villa S+2 meublé à Hammamet d'une superficie de 250 m²",
      "il se compose :",
      "-d'un spacieux salon et salle à manger",
      "-Deux chambres à coucher",
      "-une cuisine installée et bien aménagée",
      "-une salle de bain",
      "-une belle jardin",
      "Deux mois de caution sont obligatoire"
    ],
    "photos": [
      "22448/01.webp",
      "22448/02.webp",
      "22448/03.webp",
      "22448/04.webp",
      "22448/05.webp",
      "22448/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/22448"
  },
  {
    "id": "22445-appartement-louzan",
    "ref": "Ref95a",
    "status": "Loué",
    "transaction": "location",
    "type": "appartement",
    "prestige": false,
    "zone": "hammamet-centre",
    "place": "Hammamet centre-ville",
    "title": {
      "fr": "Appartement S+2 « Louzan », meublé",
      "en": "Apartment “Louzan”, furnished, 2 bedrooms",
      "ar": "شقة «لوزان» S+2 مفروشة"
    },
    "price": 1260,
    "pricePeriod": null,
    "landArea": 120,
    "livingArea": null,
    "bedrooms": 2,
    "bathrooms": 1,
    "amenities": [
      "furnished",
      "nearBeach",
      "nearAmenities"
    ],
    "description": [
      "À louer à l’année chez Green immobilière un appartement S+2 meublé à Hammamet ventre ville d'une superficie de 120 m²",
      "à proximité de toutes les commodités et à 5 minutes de la plage",
      "il se compose :",
      "-d'un spacieux salon et salle à manger",
      "-Deux chambres à coucher",
      "-une cuisine installée et bien aménagée",
      "-une salle de bain",
      "Deux mois de caution sont obligatoire"
    ],
    "photos": [
      "22445/01.webp",
      "22445/02.webp",
      "22445/03.webp",
      "22445/04.webp",
      "22445/05.webp",
      "22445/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/22445"
  },
  {
    "id": "42516-villa-bienvenu",
    "ref": "Ref148a",
    "status": "Loué",
    "transaction": "vacances",
    "type": "villa",
    "prestige": true,
    "zone": "hammamet-nord",
    "place": "Hammamet Nord",
    "title": {
      "fr": "Villa « Bienvenu »",
      "en": "Villa “Bienvenu”",
      "ar": "فيلا «بيانفنو»"
    },
    "price": 7500,
    "pricePeriod": "quinzaine",
    "landArea": 550,
    "livingArea": 350,
    "bedrooms": 6,
    "bathrooms": 4,
    "amenities": [
      "pool",
      "garden",
      "ac",
      "suites"
    ],
    "description": [
      "À louer pour des courtes durées chez Green immobilière, une luxueuse demeure de haut standing située à Hammamet nord",
      "La villa se compose de :",
      "-un grand salon",
      "-une suite parentale",
      "-5 chambres à couchers",
      "-4 salles de bains",
      "-une salle à manger",
      "-un grand jardin",
      "-une piscine",
      "La Villa est équipée de climatisation.",
      "Prix 7500 DT par quinzaine"
    ],
    "photos": [
      "42516/01.webp",
      "42516/02.webp",
      "42516/03.webp",
      "42516/04.webp",
      "42516/05.webp",
      "42516/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/42516"
  },
  {
    "id": "17514-villa-le-portugal",
    "ref": "Ref54a",
    "status": "Loué",
    "transaction": "vacances",
    "type": "villa",
    "prestige": false,
    "zone": "hammamet",
    "place": "Cité Bouslama, Hammamet",
    "title": {
      "fr": "Villa « Le Portugal »",
      "en": "Villa “Le Portugal”",
      "ar": "فيلا «البرتغال»"
    },
    "price": 5000,
    "pricePeriod": "semaine",
    "landArea": 750,
    "livingArea": 200,
    "bedrooms": 3,
    "bathrooms": 2,
    "amenities": [
      "singleLevel",
      "pool",
      "fireplace",
      "garden",
      "staffStudio",
      "ac",
      "centralHeating"
    ],
    "description": [
      "Green immobilière propose à la vente une Villa plain-pied avec beaucoup de charme, ,superficie du terrain 750 m2, couverte 200 m2 La villa se compose de : - 3 chambres à coucher et 2 salles de bain - 1 salon/ salle à manger avec cheminée donnant sur piscine - 1 jardin complanté d'orangers et de citronniers - 1 studio à l'extérieur pour le personnel - 1 puit pour la piscine La Villa est équipée de chauffage central et de climatisation. Prix 5000 DT LA SEMAINE"
    ],
    "photos": [
      "17514/01.webp",
      "17514/02.webp",
      "17514/03.webp",
      "17514/04.webp",
      "17514/05.webp",
      "17514/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/17514"
  },
  {
    "id": "17461-appartement-sherazade-vacances",
    "ref": "Ref45a",
    "status": "Loué",
    "transaction": "vacances",
    "type": "appartement",
    "prestige": false,
    "zone": "yasmine",
    "place": "Zone touristique, Hammamet",
    "title": {
      "fr": "Appartement « Shérazade »",
      "en": "Apartment “Shérazade”",
      "ar": "شقة «شهرزاد»"
    },
    "price": 1100,
    "pricePeriod": "semaine",
    "landArea": 95,
    "livingArea": 95,
    "bedrooms": 1,
    "bathrooms": 1,
    "amenities": [
      "nearBeach",
      "ac",
      "centralHeating"
    ],
    "description": [
      "Green Immobilière loue pour vos vacances à Hammamet, un bel appartement, S+1 de haut standing dans la zone touristique, d'une superficie de 95 m², à 2 min de la plage et de hôtel Badira Il offre : -un spacieux salon, salle a manger -une chambre à coucher -une cuisine moderne aménagée -une salle de bain L'appartement est équipé de chauffage central et de climatisation. 1100 TND par semaine /"
    ],
    "photos": [
      "17461/01.webp",
      "17461/02.webp",
      "17461/03.webp",
      "17461/04.webp",
      "17461/05.webp",
      "17461/06.webp"
    ],
    "source": "https://www.greenimmobiliere.tn/bien/details/17461"
  }
];
