/* ==========================================================================
   GREEN IMMOBILIER — Noyau du site
   Composants partagés : en-tête, pied de page, cartes, langues, formulaires,
   galerie plein écran, animations.
   ========================================================================== */
(function () {
  "use strict";

  /* ---------------- Coordonnées de l'agence (sources vérifiées) ----------------
     Site officiel greenimmobiliere.tn, profil Instagram et fiche Google Maps. */
  const AGENCY = {
    name: "Green Immobilier",
    address: "8050 Hammamet, Tunisie",
    mobile: "+216 98 100 513",
    mobileRaw: "21698100513",
    landline: "+216 72 263 129",
    landlineRaw: "21672263129",
    email: "contact@greenimmobiliere.com",
    instagram: "https://www.instagram.com/green_immobilier/",
    facebook: "https://www.facebook.com/Green.immobiliere/",
    messenger: "https://m.me/Green.immobiliere",
    mapsUrl: "https://maps.app.goo.gl/ySTiuvtW12bzsxab8",
    lat: 35.8210474,
    lng: 10.6392083,
    /* Optionnel : URL d'un service de formulaires (Formspree, Getform, API maison…).
       Si renseignée, les formulaires y sont envoyés en POST (JSON).
       Sinon, ils préparent le message et l'envoient par WhatsApp ou e-mail. */
    formEndpoint: ""
  };
  window.AGENCY = AGENCY;

  const LANGS = ["fr", "en", "ar"];
  const LS_KEY = "gi-lang";

  /* ---------------- Langue ---------------- */
  function detectLang() {
    const q = new URLSearchParams(location.search).get("lang");
    if (q && LANGS.includes(q)) return q;
    try { const s = localStorage.getItem(LS_KEY); if (s && LANGS.includes(s)) return s; } catch (e) {}
    return "fr";
  }
  let LANG = detectLang();

  function t(path, vars) {
    const get = (lang) => path.split(".").reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), I18N[lang]);
    let s = get(LANG);
    if (s === undefined) s = get("fr");
    if (s === undefined) return path;
    if (vars && typeof s === "string") s = s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : ""));
    return s;
  }

  function setLang(lang) {
    if (!LANGS.includes(lang) || lang === LANG) return;
    LANG = lang;
    try { localStorage.setItem(LS_KEY, lang); } catch (e) {}
    const u = new URL(location.href);
    if (lang === "fr") u.searchParams.delete("lang"); else u.searchParams.set("lang", lang);
    history.replaceState(null, "", u);
    applyLang();
    renderChrome();
    if (typeof GI.page === "function") GI.page();
    applyStatic();
    observeReveals(document);
  }

  function applyLang() {
    document.documentElement.lang = LANG;
    document.documentElement.dir = I18N[LANG].meta.dir;
  }

  /* Traduit les éléments statiques : data-i18n, data-i18n-ph, data-i18n-aria */
  function applyStatic(root) {
    (root || document).querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
    (root || document).querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    (root || document).querySelectorAll("[data-i18n-aria]").forEach((el) => { el.setAttribute("aria-label", t(el.dataset.i18nAria)); });
  }

  /* Ajoute ?lang= aux liens internes pour conserver la langue */
  function href(path) {
    if (LANG === "fr") return path;
    return path + (path.includes("?") ? "&" : "?") + "lang=" + LANG;
  }

  /* ---------------- Utilitaires ---------------- */
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nf = () => new Intl.NumberFormat(LANG === "ar" ? "ar-TN-u-nu-latn" : LANG === "en" ? "en-GB" : "fr-FR");
  const num = (n) => nf().format(n);
  const currency = () => (LANG === "ar" ? "د.ت" : LANG === "en" ? "TND" : "DT");

  function priceHTML(l) {
    if (l.price == null) {
      const extra = l.pricePeriod ? `<small> · ${esc(l.pricePeriod)}</small>` : "";
      return `<span class="price">${t("card.priceOnRequest")}${extra}</span>`;
    }
    const per = l.pricePeriod && I18N.fr.period[l.pricePeriod] ? ` <small>${t("period." + l.pricePeriod)}</small>` : "";
    return `<span class="price">${num(l.price)} ${currency()}${per}</span>`;
  }
  function priceText(l) {
    if (l.price == null) return t("card.priceOnRequest");
    return `${num(l.price)} ${currency()}${l.pricePeriod && I18N.fr.period[l.pricePeriod] ? " " + t("period." + l.pricePeriod) : ""}`;
  }

  const photo = (p, size) => window.IMG_BASE + (size === "large" ? p.replace(/\.webp$/, "-sm.webp") : p);
  const title = (l) => l.title[LANG] || l.title.fr;
  const zoneName = (key) => (window.ZONES[key] ? window.ZONES[key][LANG] || window.ZONES[key].fr : key);
  const listingUrl = (l) => href("bien.html?id=" + encodeURIComponent(l.id));
  const waLink = (text) => `https://wa.me/${AGENCY.mobileRaw}${text ? "?text=" + encodeURIComponent(text) : ""}`;
  const telLink = (raw) => "tel:+" + (raw || AGENCY.mobileRaw);
  const isAvailable = (l) => l.status === "Disponible";

  /* ---------------- Icônes (SVG inline, trait fin) ---------------- */
  const I = {
    arrow: '<svg class="arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 12h16M14 6l6 6-6 6"/></svg>',
    bed: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 18V7m0 7h18v4M21 14v-2a3 3 0 0 0-3-3h-7v5"/><circle cx="7" cy="11" r="1.6"/></svg>',
    bath: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 12h16v2a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5v-2zM6 12V6a2 2 0 0 1 4 0M7 19l-1 2M17 19l1 2"/></svg>',
    area: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 4h16v16H4zM4 9h5M15 20v-5M9 4v5"/></svg>',
    land: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 20l5-9 4 6 3-4 6 7H3z"/><circle cx="16.5" cy="6.5" r="2"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.4"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 5h18v14H3z"/><path d="M3 6l9 7 9-7"/></svg>',
    camera: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 7h3l2-3h6l2 3h3v13H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 12.5l5 5L20 6.5"/></svg>',
    key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 11l9-7 9 7M5 9.5V20h14V9.5"/></svg>',
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/></svg>',
    chevL: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M15 5l-7 7 7 7"/></svg>',
    chevR: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M9 5l7 7-7 7"/></svg>',
    filter: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 6h16M7 12h10M10 18h4"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.7-1.2 2.2 2.2 0 0 0 .2-1.2c-.1-.1-.3-.2-.5-.3z"/></svg>',
    ig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".8" fill="currentColor"/></svg>',
    fb: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-7.5h2.5l.4-3h-2.9V8.6c0-.9.3-1.5 1.5-1.5H16.5V4.4a20 20 0 0 0-2.3-.1c-2.3 0-3.8 1.4-3.8 3.9v2.3H8v3h2.4V21h3.1z"/></svg>'
  };

  /* ---------------- En-tête ---------------- */
  const NAV = [
    { key: "home", url: "index.html", id: "home" },
    { key: "buy", url: "biens.html?t=vente", id: "vente" },
    { key: "rent", url: "biens.html?t=location", id: "location" },
    { key: "holiday", url: "biens.html?t=vacances", id: "vacances" },
    { key: "properties", url: "biens.html", id: "biens" },
    { key: "about", url: "a-propos.html", id: "about" },
    { key: "contact", url: "contact.html", id: "contact" }
  ];

  function currentNavId() {
    const page = document.body.dataset.page;
    if (page === "catalogue") return new URLSearchParams(location.search).get("t") || "biens";
    return page;
  }

  function brandHTML() {
    return `<a class="brand" href="${href("index.html")}" aria-label="Green Immobilier — ${t("nav.home")}">
      <img src="assets/img/logo-mark.svg" alt="" width="38" height="38">
      <span class="brand-text"><span class="brand-name">GREEN</span><span class="brand-sub">Immobilier</span></span>
    </a>`;
  }

  function langSwitchHTML() {
    return `<div class="lang-switch" role="group" aria-label="Langue / Language / اللغة">${LANGS.map((l) =>
      `<button type="button" data-lang="${l}" aria-pressed="${l === LANG}" lang="${l}" title="${I18N[l].meta.name}"><span>${I18N[l].meta.label}</span></button>`).join("")}</div>`;
  }

  function renderChrome() {
    const active = currentNavId();
    const header = document.getElementById("site-header");
    if (header) {
      header.innerHTML = `<div class="container header-inner">
        ${brandHTML()}
        <nav class="main-nav" aria-label="Navigation principale"><ul>
          ${NAV.map((n) => `<li><a href="${href(n.url)}"${n.id === active ? ' aria-current="page"' : ""}>${t("nav." + n.key)}</a></li>`).join("")}
        </ul></nav>
        <div class="header-actions">
          ${langSwitchHTML()}
          <a class="btn header-cta" href="${href("deposer.html")}">${t("nav.submit")}</a>
          <button class="burger" type="button" aria-label="${t("nav.menu")}" aria-expanded="false" aria-controls="mobile-menu"><span></span></button>
        </div>
      </div>`;
    }
    let mm = document.getElementById("mobile-menu");
    if (!mm) { mm = document.createElement("div"); mm.id = "mobile-menu"; mm.className = "mobile-menu"; mm.setAttribute("aria-hidden", "true"); document.body.appendChild(mm); }
    mm.innerHTML = `<div class="mobile-menu-top">${brandHTML()}<button class="close-btn" type="button" aria-label="${t("nav.close")}"></button></div>
      <nav aria-label="Menu mobile"><ul>
        ${NAV.map((n, i) => `<li><a style="--i:${i}" href="${href(n.url)}"${n.id === active ? ' aria-current="page"' : ""}>${t("nav." + n.key)}</a></li>`).join("")}
      </ul></nav>
      <div class="mobile-menu-foot">
        <a class="btn btn--light btn--block" href="${href("deposer.html")}">${t("nav.submit")}</a>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
          <a href="${telLink()}" dir="ltr">${AGENCY.mobile}</a>${langSwitchHTML()}
        </div>
      </div>`;

    const footer = document.getElementById("site-footer");
    if (footer) {
      const y = new Date().getFullYear();
      footer.innerHTML = `<div class="container">
        <div class="footer-top">
          <div>${brandHTML()}<p style="max-width:34ch;margin:0">${t("footer.tagline")}</p>
            <div class="socials">
              <a href="${AGENCY.instagram}" target="_blank" rel="noopener" aria-label="Instagram">${I.ig}</a>
              <a href="${AGENCY.facebook}" target="_blank" rel="noopener" aria-label="Facebook">${I.fb}</a>
              <a href="${waLink()}" target="_blank" rel="noopener" aria-label="WhatsApp">${I.wa}</a>
            </div>
          </div>
          <div><h4>${t("footer.explore")}</h4><ul>
            <li><a href="${href("biens.html?t=vente")}">${t("nav.buy")}</a></li>
            <li><a href="${href("biens.html?t=location")}">${t("nav.rent")}</a></li>
            <li><a href="${href("biens.html?t=vacances")}">${t("nav.holiday")}</a></li>
            <li><a href="${href("biens.html?cat=prestige")}">${t("cat.prestige")}</a></li>
          </ul></div>
          <div><h4>${t("footer.agency")}</h4><ul>
            <li><a href="${href("a-propos.html")}">${t("nav.about")}</a></li>
            <li><a href="${href("deposer.html")}">${t("nav.submit")}</a></li>
            <li><a href="${href("contact.html")}">${t("nav.contact")}</a></li>
          </ul></div>
          <div><h4>${t("footer.contact")}</h4><ul>
            <li>${AGENCY.address}</li>
            <li><a href="${telLink()}" dir="ltr">${AGENCY.mobile}</a></li>
            <li><a href="${telLink(AGENCY.landlineRaw)}" dir="ltr">${AGENCY.landline}</a></li>
            <li><a href="mailto:${AGENCY.email}">${AGENCY.email}</a></li>
          </ul></div>
        </div>
        <div class="footer-bottom"><span>© ${y} Green Immobilier — ${t("footer.rights")}</span><a href="#top">${t("footer.top")} ↑</a></div>
      </div>`;
    }

    let wa = document.querySelector(".wa-float");
    if (!wa) { wa = document.createElement("a"); wa.className = "wa-float"; wa.target = "_blank"; wa.rel = "noopener"; document.body.appendChild(wa); }
    wa.href = waLink(); wa.setAttribute("aria-label", "WhatsApp " + AGENCY.mobile); wa.innerHTML = I.wa;

    bindChrome();
  }

  function bindChrome() {
    document.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", () => { setLang(b.dataset.lang); closeMenu(); }));
    const burger = document.querySelector(".burger");
    const mm = document.getElementById("mobile-menu");
    if (burger) burger.addEventListener("click", openMenu);
    mm.querySelector(".close-btn").addEventListener("click", closeMenu);
  }
  function openMenu() {
    const mm = document.getElementById("mobile-menu");
    mm.classList.add("is-open"); mm.setAttribute("aria-hidden", "false"); document.body.classList.add("no-scroll");
    const b = document.querySelector(".burger"); if (b) b.setAttribute("aria-expanded", "true");
    setTimeout(() => mm.querySelector(".close-btn").focus(), 50);
  }
  function closeMenu() {
    const mm = document.getElementById("mobile-menu");
    if (!mm || !mm.classList.contains("is-open")) return;
    mm.classList.remove("is-open"); mm.setAttribute("aria-hidden", "true"); document.body.classList.remove("no-scroll");
    const b = document.querySelector(".burger"); if (b) { b.setAttribute("aria-expanded", "false"); b.focus(); }
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeMenu(); closeLightbox(); } });

  function headerOnScroll() {
    const h = document.getElementById("site-header");
    if (!h) return;
    const y = window.scrollY;
    h.classList.toggle("is-solid", y > 40 || document.body.classList.contains("page-light"));
    h.classList.toggle("is-compact", y > 160);
  }
  window.addEventListener("scroll", headerOnScroll, { passive: true });

  /* ---------------- Carte d'annonce ---------------- */
  function specsHTML(l) {
    const out = [];
    if (l.livingArea) out.push(`<span class="spec">${I.area}${num(l.livingArea)} m²</span>`);
    else if (l.landArea && l.type === "terrain") out.push(`<span class="spec">${I.land}${num(l.landArea)} m²</span>`);
    if (l.landArea && l.type !== "terrain") out.push(`<span class="spec">${I.land}${num(l.landArea)} m² ${t("card.land")}</span>`);
    if (l.bedrooms) out.push(`<span class="spec">${I.bed}${l.bedrooms} ${t("card.beds")}</span>`);
    if (l.bathrooms) out.push(`<span class="spec">${I.bath}${l.bathrooms} ${t("card.baths")}</span>`);
    if (!l.livingArea && l.landArea && l.type !== "terrain") out.unshift();
    return out.join("");
  }

  function card(l, opts) {
    const o = opts || {};
    const off = !isAvailable(l);
    const statusBadge = off ? `<span class="badge badge--muted">${t("status." + l.status)}</span>` : "";
    return `<article class="card${off ? " is-off" : ""} reveal" style="--d:${(o.i || 0) % 3 * 90}ms">
      <div class="card-media">
        <img src="${photo(l.photos[0], "large")}" alt="${esc(title(l))}" loading="lazy" decoding="async" width="600" height="450">
        <div class="badges"><span class="badge">${t("tx." + l.transaction)}</span>${l.prestige ? `<span class="badge badge--dark">Prestige</span>` : ""}${statusBadge}</div>
        <span class="card-photos">${I.camera}${l.photos.length}</span>
      </div>
      <div class="card-body">
        <span class="card-place">${t("type." + l.type)} · ${esc(zoneName(l.zone))}</span>
        <h3 class="card-title"><a href="${listingUrl(l)}">${esc(title(l))}</a></h3>
        <div class="card-specs">${specsHTML(l)}</div>
        <div class="card-foot">${priceHTML(l)}<span class="card-cta">${t("card.discover")}${I.arrow}</span></div>
      </div>
    </article>`;
  }

  /* ---------------- Animations d'apparition ---------------- */
  let io;
  function observeReveals(root) {
    const els = (root || document).querySelectorAll(".reveal:not(.is-in), .img-reveal:not(.is-in)");
    if (!("IntersectionObserver" in window)) { els.forEach((e) => e.classList.add("is-in")); return; }
    if (!io) io = new IntersectionObserver((entries) => entries.forEach((en) => {
      if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); }
    }), { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    els.forEach((e) => io.observe(e));
  }

  /* ---------------- Galerie plein écran ---------------- */
  let LB = null;
  function openLightbox(photos, index, label) {
    if (!LB) {
      LB = document.createElement("div");
      LB.className = "lightbox"; LB.setAttribute("role", "dialog"); LB.setAttribute("aria-modal", "true");
      document.body.appendChild(LB);
    }
    let i = index || 0;
    LB.setAttribute("aria-label", label || "Galerie");
    LB.innerHTML = `<div class="lb-top"><span class="lb-count"></span><button class="close-btn" type="button" aria-label="${t("nav.close")}"></button></div>
      <div class="lb-stage"><button class="lb-nav lb-prev" type="button" aria-label="Précédent">${I.chevL}</button><img alt=""><button class="lb-nav lb-next" type="button" aria-label="Suivant">${I.chevR}</button></div>
      <div class="lb-thumbs">${photos.map((p, k) => `<button type="button" data-k="${k}"><img src="${photo(p, "large")}" alt="" loading="lazy"></button>`).join("")}</div>`;
    const img = LB.querySelector(".lb-stage img");
    const show = (k) => {
      i = (k + photos.length) % photos.length;
      img.style.opacity = 0;
      const n = new Image(); n.src = photo(photos[i]);
      n.onload = n.onerror = () => { img.src = n.src; img.alt = (label || "") + " — " + (i + 1); img.style.opacity = 1; };
      LB.querySelector(".lb-count").textContent = `${i + 1} / ${photos.length}`;
      LB.querySelectorAll(".lb-thumbs button").forEach((b, k2) => b.setAttribute("aria-current", k2 === i));
      const cur = LB.querySelector(`.lb-thumbs button[data-k="${i}"]`); if (cur) cur.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
      // précharge la suivante
      const nx = new Image(); nx.src = photo(photos[(i + 1) % photos.length]);
    };
    const rtl = document.documentElement.dir === "rtl";
    LB.querySelector(".lb-prev").onclick = () => show(i - 1);
    LB.querySelector(".lb-next").onclick = () => show(i + 1);
    LB.querySelector(".close-btn").onclick = closeLightbox;
    LB.querySelectorAll(".lb-thumbs button").forEach((b) => (b.onclick = () => show(+b.dataset.k)));
    LB._key = (e) => {
      if (e.key === "ArrowRight") show(rtl ? i - 1 : i + 1);
      if (e.key === "ArrowLeft") show(rtl ? i + 1 : i - 1);
    };
    document.addEventListener("keydown", LB._key);
    let x0 = null;
    const stage = LB.querySelector(".lb-stage");
    stage.addEventListener("touchstart", (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    stage.addEventListener("touchend", (e) => {
      if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) > 45) show((dx < 0) !== rtl ? i + 1 : i - 1);
    });
    LB._ret = document.activeElement;
    LB.classList.add("is-open"); document.body.classList.add("no-scroll");
    show(i);
    setTimeout(() => LB.querySelector(".close-btn").focus(), 50);
  }
  function closeLightbox() {
    if (!LB || !LB.classList.contains("is-open")) return;
    LB.classList.remove("is-open"); document.body.classList.remove("no-scroll");
    document.removeEventListener("keydown", LB._key);
    if (LB._ret) LB._ret.focus();
  }

  /* ---------------- Formulaires ----------------
     Validation, puis envoi :
     - vers AGENCY.formEndpoint si configuré (POST JSON) ;
     - sinon, le message est composé et proposé via WhatsApp ou e-mail. */
  function initForm(form, opts) {
    const o = opts || {};
    const ok = form.parentElement.querySelector(".form-ok");
    form.setAttribute("novalidate", "");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      let valid = true;
      form.querySelectorAll("[required]").forEach((f) => {
        const wrap = f.closest(".form-field") || f.parentElement;
        let msg = "";
        if (f.type === "checkbox" ? !f.checked : !f.value.trim()) msg = t("form.required");
        else if (f.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.value.trim())) msg = t("form.invalidEmail");
        wrap.classList.toggle("invalid", !!msg);
        const err = wrap.querySelector(".err"); if (err) err.textContent = msg;
        if (msg && valid) { valid = false; f.focus(); }
      });
      if (!valid) return;

      const data = Object.fromEntries(new FormData(form).entries());
      const subject = (o.subject ? o.subject(data) : "Demande") + " — site Green Immobilier";
      const body = o.message ? o.message(data) : Object.entries(data).map(([k, v]) => `${k}: ${v}`).join("\n");

      const btn = form.querySelector('[type="submit"]');
      if (AGENCY.formEndpoint) {
        btn.disabled = true;
        try {
          const r = await fetch(AGENCY.formEndpoint, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ _subject: subject, ...data, message_complet: body }) });
          if (!r.ok) throw new Error(r.status);
          ok.innerHTML = `<b>${t("form.okSent")}</b>`;
          ok.classList.add("is-visible"); form.reset();
        } catch (err) {
          ok.innerHTML = `<p>${t("form.error")}</p>`; ok.classList.add("is-visible");
        } finally { btn.disabled = false; }
        return;
      }
      ok.innerHTML = `<b>${t("form.okTitle")}</b><p>${t("form.okText")}</p>
        <div class="btn-row">
          <a class="btn btn--wa" target="_blank" rel="noopener" href="${waLink(body)}">${I.wa}${t("form.viaWa")}</a>
          <a class="btn btn--ghost" href="mailto:${AGENCY.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}">${I.mail}${t("form.viaMail")}</a>
        </div>`;
      ok.classList.add("is-visible");
      ok.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
    form.addEventListener("input", (e) => {
      const wrap = e.target.closest(".form-field"); if (wrap && wrap.classList.contains("invalid")) { wrap.classList.remove("invalid"); const err = wrap.querySelector(".err"); if (err) err.textContent = ""; }
    });
  }

  function toast(msg) {
    let el = document.querySelector(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = msg; el.classList.add("is-visible");
    clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove("is-visible"), 2200);
  }

  /* ---------------- API publique ---------------- */
  window.GI = {
    AGENCY, I, t, href, esc, num, currency, priceHTML, priceText, photo, title, zoneName, listingUrl, waLink, telLink, isAvailable,
    card, specsHTML, openLightbox, initForm, observeReveals, applyStatic, toast,
    get lang() { return LANG; },
    page: null
  };

  /* ---------------- Démarrage ---------------- */
  applyLang();
  document.addEventListener("DOMContentLoaded", () => {
    renderChrome();
    if (typeof GI.page === "function") GI.page();
    applyStatic();
    headerOnScroll();
    observeReveals(document);
  });
})();
