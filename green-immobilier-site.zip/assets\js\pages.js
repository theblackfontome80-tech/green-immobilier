/* ==========================================================================
   GREEN IMMOBILIER — Logique des pages
   Chaque page déclare <body data-page="..."> ; la fonction correspondante
   est (re)lancée au chargement et à chaque changement de langue.
   ========================================================================== */
(function () {
  "use strict";
  const { t, href, esc, num, I, card, photo, title, zoneName, listingUrl, waLink, telLink, priceHTML, priceText, isAvailable, AGENCY } = GI;
  const L = window.LISTINGS;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const placeOf = (l) => (GI.lang === "fr" ? l.place : l.zone === "hammamet" ? zoneName(l.zone) : zoneName(l.zone) + " — " + (GI.lang === "ar" ? "الحمامات" : "Hammamet"));
  const byNewest = (a, b) => parseInt(b.id) - parseInt(a.id);

  const CATS = {
    villas: (l) => l.type === "villa",
    appartements: (l) => l.type === "appartement",
    maisons: (l) => l.type === "maison",
    terrains: (l) => l.type === "terrain",
    prestige: (l) => l.prestige,
    saison: (l) => l.transaction === "vacances"
  };
  const CAT_IMG = { villas: "140792", appartements: "22445", maisons: "17514", terrains: "98180", prestige: "140341", saison: "42516" };
  const imgOf = (idPrefix, k) => { const l = L.find((x) => x.id.startsWith(idPrefix + "-")); return l ? photo(l.photos[k || 0], "large") : ""; };

  function zonesOptions(selected) {
    const keys = Object.keys(ZONES).filter((z) => L.some((l) => l.zone === z));
    return `<option value="">${t("search.anyLocation")}</option>` + keys.map((z) => `<option value="${z}"${z === selected ? " selected" : ""}>${esc(zoneName(z))}</option>`).join("");
  }
  function typeOptions(selected) {
    return `<option value="">${t("search.anyType")}</option>` + ["villa", "appartement", "maison", "terrain"].map((k) => `<option value="${k}"${k === selected ? " selected" : ""}>${t("type." + k)}</option>`).join("");
  }
  const BUDGETS = {
    vente: [200000, 300000, 500000, 750000, 1000000, 1500000, 2000000, 3000000],
    location: [1000, 1500, 2000, 3000, 5000, 8000],
    vacances: [1000, 2000, 3000, 5000, 8000]
  };
  function budgetOptions(tx, selected) {
    return `<option value="">${t("search.any")}</option>` + BUDGETS[tx].map((v) => `<option value="${v}"${String(v) === String(selected) ? " selected" : ""}>${num(v)} ${GI.currency()}</option>`).join("");
  }

  /* ====================================================================
     ACCUEIL
     ==================================================================== */
  function home() {
    const heroL = L.find((l) => l.id.startsWith("140341-"));
    const prestige = L.filter((l) => l.prestige && l.transaction === "vente" && isAvailable(l)).slice(0, 4);
    const latest = L.filter((l) => isAvailable(l) && !prestige.includes(l)).sort(byNewest).slice(0, 6);
    let tx = $("#home")?.dataset.tx || "vente";

    $("#home").innerHTML = `
    <section class="hero">
      <div class="hero-media"><img src="${photo(heroL.photos[0])}" alt="${esc(title(heroL))}" fetchpriority="high" width="1600" height="1067"></div>
      <div class="container hero-content">
        <span class="eyebrow hero-in">${t("hero.eyebrow")}</span>
        <h1 class="h1 hero-in" style="--d:120ms">${t("hero.title")}</h1>
        <p class="hero-sub hero-in" style="--d:240ms">${t("hero.subtitle")}</p>
        <form class="search-panel hero-in" style="--d:360ms" id="hero-search" role="search" action="biens.html">
          <div class="search-tabs" role="tablist">
            ${[["vente", "buy"], ["location", "rent"], ["vacances", "holiday"]].map(([k, lbl]) => `<button type="button" role="tab" data-tx="${k}" aria-selected="${k === tx}">${t("search." + lbl)}</button>`).join("")}
          </div>
          <div class="search-fields">
            <div class="field"><label for="s-type">${t("search.type")}</label><select id="s-type" name="type">${typeOptions()}</select></div>
            <div class="field"><label for="s-zone">${t("search.location")}</label><select id="s-zone" name="zone">${zonesOptions()}</select></div>
            <div class="field"><label for="s-min">${t("search.budgetMin")}</label><select id="s-min" name="min">${budgetOptions(tx)}</select></div>
            <div class="field"><label for="s-max">${t("search.budgetMax")}</label><select id="s-max" name="max">${budgetOptions(tx)}</select></div>
            <button class="btn search-submit" type="submit">${t("search.submit")}${I.arrow}</button>
          </div>
        </form>
      </div>
      <div class="container hero-caption"><span>${t("hero.caption")}</span><a href="#intro"><span>${t("hero.scroll")}</span><span class="scroll-line"></span></a></div>
    </section>

    <section class="section" id="intro">
      <div class="container">
        <div class="intro-grid">
          <span class="eyebrow reveal">${t("home.introEyebrow")}</span>
          <div>
            <h2 class="h2 reveal">${t("home.introTitle")}</h2>
            <p class="lead reveal" style="margin-top:26px">${t("home.introText")}</p>
          </div>
        </div>
        <div class="services">
          ${[["vente", "s1"], ["location", "s2"], ["vacances", "s3"]].map(([k, s], i) => `
            <div class="service reveal" style="--d:${i * 100}ms">
              <span class="service-num">0${i + 1}</span>
              <h3>${t("home." + s + "t")}</h3>
              <p>${t("home." + s + "d")}</p>
              <a class="link-arrow" href="${href("biens.html?t=" + k)}">${t("card.discover")}${I.arrow}</a>
            </div>`).join("")}
        </div>
      </div>
    </section>

    <section class="section section--sand" id="exception">
      <div class="container">
        <div class="section-head section-head--split">
          <div><span class="eyebrow reveal">${t("home.exEyebrow")}</span><h2 class="h2 reveal" style="margin-top:18px">${t("home.exTitle")}</h2></div>
          <p class="lead reveal">${t("home.exText")}</p>
        </div>
        <div class="exception">
          ${prestige.map((l, i) => `
          <article class="ex-item">
            <a class="ex-media img-reveal" href="${listingUrl(l)}" aria-label="${esc(title(l))}">
              <img src="${photo(l.photos[0])}" alt="${esc(title(l))}" loading="lazy" decoding="async" width="1200" height="900">
              <span class="ex-media-2"><img src="${photo(l.photos[Math.min(3, l.photos.length - 1)], "large")}" alt="" loading="lazy"></span>
            </a>
            <div class="ex-body reveal">
              <span class="ex-index">N° 0${i + 1} — ${t("tx." + l.transaction)}</span>
              <h3>${esc(title(l))}</h3>
              <span class="ex-place">${esc(placeOf(l))}</span>
              <div class="ex-facts">${GI.specsHTML(l)}</div>
              <div class="ex-price">${priceText(l)}</div>
              <a class="btn btn--ghost" href="${listingUrl(l)}">${t("home.exCta")}${I.arrow}</a>
            </div>
          </article>`).join("")}
        </div>
      </div>
    </section>

    <section class="section" id="latest">
      <div class="container">
        <div class="section-head section-head--split">
          <div><span class="eyebrow reveal">${t("home.latestEyebrow")}</span><h2 class="h2 reveal" style="margin-top:18px">${t("home.latestTitle")}</h2></div>
          <div class="reveal" style="justify-self:end"><a class="link-arrow" href="${href("biens.html")}">${t("home.latestCta")}${I.arrow}</a></div>
        </div>
        <div class="grid-cards">${latest.map((l, i) => card(l, { i })).join("")}</div>
      </div>
    </section>

    <section class="section section--ivory" id="categories" style="padding-top:clamp(64px,8vw,110px)">
      <div class="container">
        <div class="section-head"><h2 class="h2 reveal">${t("home.catTitle")}</h2></div>
        <div class="cats" style="--n:${Object.keys(CATS).filter((c) => L.some(CATS[c])).length}">
          ${Object.keys(CATS).filter((c) => L.some(CATS[c])).map((c, i) => {
            const n = L.filter(CATS[c]).length;
            return `<a class="cat reveal${n ? "" : " cat--empty"}" style="--d:${i * 60}ms" href="${href("biens.html?cat=" + c)}">
              ${n ? `<img src="${imgOf(CAT_IMG[c], c === "terrains" ? 0 : 1)}" alt="" loading="lazy">` : ""}
              <div class="cat-body"><h3>${t("cat." + c)}</h3><span>${n} ${t("home.catCount")}</span></div>
            </a>`;
          }).join("")}
        </div>
      </div>
    </section>

    <section class="section section--dark" id="approche">
      <div class="container about-split">
        <div class="about-media img-reveal"><img src="${imgOf("140792", 4)}" alt="" loading="lazy"></div>
        <div>
          <span class="eyebrow reveal">${t("home.aboutEyebrow")}</span>
          <h2 class="h2 reveal" style="margin-top:18px">${t("home.aboutTitle")}</h2>
          <ul class="values">
            ${[1, 2, 3, 4, 5].map((k) => `<li class="reveal" style="--d:${k * 60}ms"><span class="n">0${k}</span><div><b>${t("about.v" + k + "t")}</b><p>${t("about.v" + k + "d")}</p></div></li>`).join("")}
          </ul>
          <a class="link-arrow reveal" href="${href("a-propos.html")}">${t("home.aboutCta")}${I.arrow}</a>
        </div>
      </div>
      <div class="container" style="margin-top:clamp(80px,10vw,140px)">
        <div class="section-head section-head--split">
          <div><span class="eyebrow reveal">${t("home.zonesEyebrow")}</span><h2 class="h2 reveal" style="margin-top:18px">${t("home.zonesTitle")}</h2></div>
          <p class="lead reveal">${t("home.zonesText")}</p>
        </div>
        <div class="zones">
          ${["hammamet-nord", "zone-theatre", "hammamet-sud", "yasmine"].map((z, i) => {
            const n = L.filter((l) => l.zone === z).length;
            return `<a class="zone reveal" style="--d:${i * 80}ms" href="${href("biens.html?zone=" + z)}"><h3>${esc(zoneName(z))}</h3><span>${n} ${t("home.catCount")}</span></a>`;
          }).join("")}
        </div>
      </div>
    </section>

    <section class="cta-band">
      <img src="${imgOf("139228", 2)}" alt="" loading="lazy">
      <div class="container">
        <span class="eyebrow reveal" style="color:var(--olive-soft)">Green Immobilier</span>
        <h2 class="h2 reveal">${t("home.ctaTitle")}</h2>
        <p class="reveal">${t("home.ctaText")}</p>
        <div class="btn-row reveal">
          <a class="btn btn--light" href="${href("deposer.html")}">${t("home.ctaBtn")}${I.arrow}</a>
          <a class="btn btn--outline-light" href="${telLink()}">${I.phone}<span dir="ltr">${AGENCY.mobile}</span></a>
        </div>
      </div>
    </section>`;

    // Moteur de recherche
    const form = $("#hero-search");
    $$(".search-tabs button", form).forEach((b) => b.addEventListener("click", () => {
      tx = b.dataset.tx; $("#home").dataset.tx = tx;
      $$(".search-tabs button", form).forEach((x) => x.setAttribute("aria-selected", x === b));
      $("#s-min").innerHTML = budgetOptions(tx); $("#s-max").innerHTML = budgetOptions(tx);
    }));
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const p = new URLSearchParams({ t: tx });
      ["type", "zone", "min", "max"].forEach((k) => { const v = form.elements[k].value; if (v) p.set(k, v); });
      if (GI.lang !== "fr") p.set("lang", GI.lang);
      location.href = "biens.html?" + p.toString();
    });
  }

  /* ====================================================================
     CATALOGUE
     ==================================================================== */
  function catalogue() {
    const root = $("#catalogue");
    const q = new URLSearchParams(location.search);
    const S = root._state || {
      t: q.get("t") || "", type: q.get("type") || "", zone: q.get("zone") || "", min: q.get("min") || "", max: q.get("max") || "",
      smin: q.get("smin") || "", beds: q.get("beds") || "", cat: q.get("cat") || "", avail: q.get("avail") === "1", sort: q.get("sort") || "recent"
    };
    root._state = S;
    const heading = S.t === "vente" ? t("list.titleVente") : S.t === "location" ? t("list.titleLocation") : S.t === "vacances" ? t("list.titleVacances") : (S.cat ? t("cat." + S.cat) : t("list.title"));
    document.title = `${heading} à Hammamet | Green Immobilier`;

    root.innerHTML = `
    <section class="page-hero">
      <div class="container">
        <nav class="breadcrumb" aria-label="Fil d'Ariane"><a href="${href("index.html")}">${t("nav.home")}</a><span aria-hidden="true">/</span><span>${esc(heading)}</span></nav>
        <h1 class="display">${esc(heading)}</h1>
        <p class="lead">${t("list.subtitle")}</p>
        <div class="chips" role="group" aria-label="Catégories">
          <button class="chip" type="button" data-cat="" aria-pressed="${!S.cat}">${t("cat.all")}</button>
          ${Object.keys(CATS).map((c) => `<button class="chip" type="button" data-cat="${c}" aria-pressed="${S.cat === c}">${t("cat." + c)} <span class="muted">(${L.filter(CATS[c]).length})</span></button>`).join("")}
        </div>
      </div>
    </section>
    <section class="section" style="padding-top:48px">
      <div class="container catalog">
        <aside class="filters" id="filters" aria-label="${t("list.filters")}">
          <div class="filters-head"><h2>${t("list.filters")}</h2><button type="button" class="link-arrow" data-reset style="border:0;padding:0">${t("list.reset")}</button></div>
          <div class="f-group"><span class="label">${t("list.transaction")}</span>
            <div class="seg">${[["", "list.all"], ["vente", "txShort.vente"], ["location", "txShort.location"], ["vacances", "txShort.vacances"]].map(([v, k]) => `<button type="button" data-f="t" data-v="${v}" aria-pressed="${S.t === v}">${t(k)}</button>`).join("")}</div>
          </div>
          <div class="f-group"><label class="label" for="f-type">${t("list.type")}</label><select class="select" id="f-type" data-f="type">${typeOptions(S.type)}</select></div>
          <div class="f-group"><label class="label" for="f-zone">${t("list.zone")}</label><select class="select" id="f-zone" data-f="zone">${zonesOptions(S.zone)}</select></div>
          <div class="f-group"><span class="label">${t("list.budget")}</span>
            <div class="duo"><input class="input" type="number" inputmode="numeric" min="0" step="1000" data-f="min" value="${esc(S.min)}" placeholder="${t("list.min")}" aria-label="${t("list.budget")} ${t("list.min")}">
            <input class="input" type="number" inputmode="numeric" min="0" step="1000" data-f="max" value="${esc(S.max)}" placeholder="${t("list.max")}" aria-label="${t("list.budget")} ${t("list.max")}"></div>
          </div>
          <div class="f-group"><label class="label" for="f-smin">${t("list.surface")}</label><input class="input" id="f-smin" type="number" inputmode="numeric" min="0" step="10" data-f="smin" value="${esc(S.smin)}" placeholder="—"></div>
          <div class="f-group"><span class="label">${t("list.bedrooms")}</span>
            <div class="pills">${["", "1", "2", "3", "4", "5"].map((v) => `<button type="button" data-f="beds" data-v="${v}" aria-pressed="${S.beds === v}">${v ? v + "+" : t("list.all")}</button>`).join("")}</div>
          </div>
          <label class="check"><input type="checkbox" data-f="avail" ${S.avail ? "checked" : ""}> ${t("list.onlyAvailable")}</label>
          <div class="filters-mobile-foot"><button type="button" class="btn btn--ghost" data-reset>${t("list.reset")}</button><button type="button" class="btn" data-close-filters>${t("list.apply")}</button></div>
        </aside>
        <div>
          <div class="toolbar">
            <span class="count" aria-live="polite" id="count"></span>
            <div style="display:flex;gap:10px;align-items:center">
              <button type="button" class="btn btn--ghost filters-toggle" data-open-filters style="min-height:42px;padding:0 16px">${I.filter}${t("list.filters")}</button>
              <label class="sr-only" for="sort">${t("list.sort")}</label>
              <select class="select" id="sort" data-f="sort">
                ${[["recent", "sortRecent"], ["asc", "sortAsc"], ["desc", "sortDesc"], ["surface", "sortSurface"]].map(([v, k]) => `<option value="${v}"${S.sort === v ? " selected" : ""}>${t("list." + k)}</option>`).join("")}
              </select>
            </div>
          </div>
          <div class="grid-cards" id="results" style="grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr))"></div>
        </div>
      </div>
    </section>`;

    const apply = () => {
      const min = +S.min || 0, max = +S.max || Infinity, smin = +S.smin || 0, beds = +S.beds || 0;
      let res = L.filter((l) =>
        (!S.t || l.transaction === S.t) && (!S.type || l.type === S.type) && (!S.zone || l.zone === S.zone) &&
        (!S.cat || CATS[S.cat](l)) && (!S.avail || isAvailable(l)) &&
        (!(S.min || S.max) || (l.price != null && l.price >= min && l.price <= max)) &&
        (!smin || (l.livingArea || l.landArea || 0) >= smin) && (!beds || (l.bedrooms || 0) >= beds));
      const avail = (l) => (isAvailable(l) ? 0 : 1);
      const sorters = {
        recent: (a, b) => avail(a) - avail(b) || byNewest(a, b),
        asc: (a, b) => avail(a) - avail(b) || (a.price ?? 1e12) - (b.price ?? 1e12),
        desc: (a, b) => avail(a) - avail(b) || (b.price ?? -1) - (a.price ?? -1),
        surface: (a, b) => avail(a) - avail(b) || (b.livingArea || b.landArea || 0) - (a.livingArea || a.landArea || 0)
      };
      res.sort(sorters[S.sort] || sorters.recent);
      $("#count").textContent = t("list.results", { n: res.length });
      $("#results").innerHTML = res.length ? res.map((l, i) => card(l, { i })).join("") :
        `<div class="empty" style="grid-column:1/-1"><p>${t("list.empty")}</p><a class="btn" href="${href("contact.html")}">${t("list.emptyCta")}${I.arrow}</a></div>`;
      // Animation d'apparition au premier affichage uniquement (pas à chaque filtre)
      if (root._shown) $$("#results .reveal").forEach((e) => e.classList.add("is-in"));
      else GI.observeReveals($("#results"));
      root._shown = true;
      // URL partageable
      const p = new URLSearchParams();
      Object.entries(S).forEach(([k, v]) => { if (v && !(k === "sort" && v === "recent")) p.set(k, v === true ? "1" : v); });
      if (GI.lang !== "fr") p.set("lang", GI.lang);
      history.replaceState(null, "", "biens.html" + (p.toString() ? "?" + p : ""));
    };

    // Interactions
    $$("[data-cat]", root).forEach((b) => b.addEventListener("click", () => { S.cat = b.dataset.cat; catalogue(); }));
    $$("button[data-f]", root).forEach((b) => b.addEventListener("click", () => {
      S[b.dataset.f] = b.dataset.v;
      $$(`button[data-f="${b.dataset.f}"]`, root).forEach((x) => x.setAttribute("aria-pressed", x === b));
      if (b.dataset.f === "t") { catalogue(); return; }
      apply();
    }));
    $$("select[data-f], input[data-f]", root).forEach((el) => el.addEventListener(el.tagName === "INPUT" && el.type !== "checkbox" ? "input" : "change", () => {
      S[el.dataset.f] = el.type === "checkbox" ? el.checked : el.value; apply();
    }));
    $$("[data-reset]", root).forEach((b) => b.addEventListener("click", () => {
      Object.assign(S, { t: "", type: "", zone: "", min: "", max: "", smin: "", beds: "", cat: "", avail: false, sort: "recent" }); catalogue();
    }));
    const fl = $("#filters");
    $("[data-open-filters]", root).addEventListener("click", () => { fl.classList.add("is-open"); document.body.classList.add("no-scroll"); });
    $("[data-close-filters]", root).addEventListener("click", () => { fl.classList.remove("is-open"); document.body.classList.remove("no-scroll"); });
    apply();
  }

  /* ====================================================================
     FICHE BIEN
     ==================================================================== */
  function property() {
    const root = $("#property");
    const id = new URLSearchParams(location.search).get("id");
    const l = L.find((x) => x.id === id) || L.find((x) => id && x.id.split("-")[0] === id.split("-")[0]);
    if (!l) {
      root.innerHTML = `<section class="page-hero"><div class="container"><h1 class="display">${t("prop.notFound")}</h1><p style="margin-top:30px"><a class="btn" href="${href("biens.html")}">${t("prop.back")}${I.arrow}</a></p></div></section>`;
      return;
    }
    const name = title(l);
    const ref = l.ref || "";
    document.title = `${name} — ${priceText(l)} | Green Immobilier Hammamet`;
    setMeta("description", (l.description[0] || name).slice(0, 155));
    setMeta("og:title", name, true); setMeta("og:image", photo(l.photos[0]), true);
    injectJsonLd(l);

    const waText = t("prop.waMsg", { title: name, ref }) + location.href.split("?")[0] + "?id=" + l.id;
    const facts = [
      l.livingArea && [I.area, num(l.livingArea) + " m²", t("prop.living")],
      l.landArea && [I.land, num(l.landArea) + " m²", t("prop.land")],
      l.bedrooms && [I.bed, l.bedrooms, t("prop.bedrooms")],
      l.bathrooms && [I.bath, l.bathrooms, t("prop.bathrooms")]
    ].filter(Boolean);
    const rows = [
      [t("prop.transaction"), t("tx." + l.transaction)], [t("prop.type"), t("type." + l.type)], [t("prop.zone"), esc(placeOf(l))],
      l.landArea && [t("prop.land"), num(l.landArea) + " m²"], l.livingArea && [t("prop.living"), num(l.livingArea) + " m²"],
      l.bedrooms && [t("prop.bedrooms"), l.bedrooms], l.bathrooms && [t("prop.bathrooms"), l.bathrooms],
      ref && [t("prop.ref"), ref], [t("prop.status"), t("status." + l.status)]
    ].filter(Boolean);
    const similar = L.filter((x) => x !== l && x.transaction === l.transaction && x.type === l.type).sort((a, b) => (isAvailable(b) - isAvailable(a)) || Math.abs((a.price || 0) - (l.price || 0)) - Math.abs((b.price || 0) - (l.price || 0))).slice(0, 3);
    const mapQ = encodeURIComponent((ZONES[l.zone] && ZONES[l.zone].map) || "Hammamet, Tunisie");
    const g = l.photos.slice(0, 5);

    root.innerHTML = `
    <section class="prop-head">
      <div class="container">
        <nav class="breadcrumb" aria-label="Fil d'Ariane"><a href="${href("index.html")}">${t("nav.home")}</a><span aria-hidden="true">/</span><a href="${href("biens.html?t=" + l.transaction)}">${t("tx." + l.transaction)}</a><span aria-hidden="true">/</span><span>${esc(name)}</span></nav>
        <div class="prop-title-row">
          <div>
            <div class="badges" style="position:static"><span class="badge badge--dark">${t("tx." + l.transaction)}</span>${l.prestige ? '<span class="badge" style="background:var(--sand)">Prestige</span>' : ""}<span class="badge" style="background:var(--sand)">${t("status." + l.status)}</span></div>
            <h1 class="display" style="margin-top:18px">${esc(name)}</h1>
            <div class="prop-meta"><span class="spec">${I.pin}${esc(placeOf(l))}</span>${ref ? `<span>${t("prop.ref")} ${esc(ref)}</span>` : ""}
              <button type="button" class="spec" data-share style="font-size:14.5px;color:var(--green-800)">${I.share}${t("prop.share")}</button></div>
          </div>
          <div class="prop-price">${priceHTML(l)}</div>
        </div>
      </div>
    </section>
    <div class="container gallery-wrap">
      <div class="gallery">
        ${g.map((p, i) => `<button type="button" data-k="${i}" aria-label="${t("prop.allPhotos", { n: l.photos.length })} — ${i + 1}"><img src="${photo(p, i === 0 ? null : "large")}" alt="${esc(name)} — ${i + 1}" ${i ? 'loading="lazy"' : 'fetchpriority="high"'} decoding="async"></button>`).join("")}
      </div>
      ${l.photos.length > 1 ? `<div class="gallery-all"><button type="button" class="btn btn--light" data-k="0">${I.camera}${t("prop.allPhotos", { n: l.photos.length })}</button></div>` : ""}
    </div>
    <div class="container prop-layout">
      <div>
        ${facts.length ? `<div class="prop-section reveal"><div class="keyfacts">${facts.map(([ic, v, lab]) => `<div class="keyfact">${ic}<b>${v}</b><span>${lab}</span></div>`).join("")}</div></div>` : ""}
        <div class="prop-section reveal">
          <h2>${t("prop.description")}</h2>
          ${GI.lang !== "fr" ? `<p class="lang-note" lang="${GI.lang}">${t("prop.originalLang")}</p>` : ""}
          <div class="prose" lang="fr" dir="ltr" id="prose">${l.description.map((p) => `<p>${esc(p)}</p>`).join("")}</div>
          <button type="button" class="link-arrow read-more" id="read-more" hidden></button>
        </div>
        <div class="prop-section reveal">
          <h2>${t("prop.features")}</h2>
          <table class="spec-table"><tbody>${rows.map(([k, v]) => `<tr><th scope="row">${k}</th><td>${v}</td></tr>`).join("")}</tbody></table>
        </div>
        ${l.amenities.length ? `<div class="prop-section reveal"><h2>${t("prop.amenities")}</h2><ul class="amenities">${l.amenities.map((a) => `<li>${I.check}${t("amenity." + a)}</li>`).join("")}</ul></div>` : ""}
        <div class="prop-section reveal">
          <h2>${t("prop.location")}</h2>
          <div class="map-frame"><iframe title="${t("prop.location")} — ${esc(placeOf(l))}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://maps.google.com/maps?q=${mapQ}&z=14&hl=${GI.lang}&output=embed"></iframe></div>
          <p class="map-note">${I.pin.replace("<svg", '<svg style="width:14px;height:14px;display:inline;vertical-align:-2px"')} ${esc(placeOf(l))} — ${t("prop.mapNote")}</p>
        </div>
      </div>
      <aside class="side-card" id="contact-card">
        <div class="agent"><img src="assets/img/logo-mark.svg" alt=""><div><b>Green Immobilier</b><span>${AGENCY.address}</span></div></div>
        <h3>${t("prop.interested")}</h3>
        <p>${t("prop.interestedText")}</p>
        <div class="side-actions">
          <a class="btn btn--wa" target="_blank" rel="noopener" href="${waLink(waText)}">${I.wa}${t("prop.whatsapp")}</a>
          <a class="btn btn--ghost" href="${telLink()}">${I.phone}${t("prop.call")}</a>
        </div>
        ${formHTML("prop", { message: t("form.defaultMsg") })}
      </aside>
    </div>
    ${similar.length ? `<section class="section section--ivory"><div class="container"><div class="section-head"><h2 class="h2 reveal">${t("prop.similar")}</h2></div><div class="grid-cards">${similar.map((x, i) => card(x, { i })).join("")}</div></div></section>` : ""}
    <div class="mobile-bar">
      <a class="btn btn--wa" target="_blank" rel="noopener" href="${waLink(waText)}">${I.wa}WhatsApp</a>
      <a class="btn btn--ghost" href="${telLink()}">${I.phone}${t("prop.call")}</a>
      <a class="btn" href="#contact-card">${I.mail}${t("form.message")}</a>
    </div>`;
    document.body.classList.add("has-mobile-bar");

    $$("[data-k]", root).forEach((b) => b.addEventListener("click", () => GI.openLightbox(l.photos, +b.dataset.k, name)));
    $("[data-share]", root).addEventListener("click", async () => {
      const url = location.href;
      try { if (navigator.share) await navigator.share({ title: name, url }); else { await navigator.clipboard.writeText(url); GI.toast(t("prop.copied")); } } catch (e) {}
    });
    const prose = $("#prose"), more = $("#read-more");
    if (prose.scrollHeight > 520) {
      prose.classList.add("is-collapsed"); more.hidden = false;
      const label = { fr: ["Lire la suite", "Réduire"], en: ["Read more", "Show less"], ar: ["اقرأ المزيد", "عرض أقل"] }[GI.lang];
      more.textContent = label[0];
      more.onclick = () => { const c = prose.classList.toggle("is-collapsed"); more.textContent = label[c ? 0 : 1]; };
    }
    GI.initForm($("form", root), {
      subject: () => `${name} (${ref})`,
      message: (d) => `${t("prop.waMsg", { title: name, ref })}\n\n${d.message}\n\n— ${d.name}\n${d.phone}${d.email ? "\n" + d.email : ""}\n${location.href}`
    });
  }

  function setMeta(name, content, og) {
    let m = document.querySelector(`meta[${og ? "property" : "name"}="${name}"]`);
    if (!m) { m = document.createElement("meta"); m.setAttribute(og ? "property" : "name", name); document.head.appendChild(m); }
    m.setAttribute("content", content);
  }
  function injectJsonLd(l) {
    let s = document.getElementById("ld-listing");
    if (!s) { s = document.createElement("script"); s.type = "application/ld+json"; s.id = "ld-listing"; document.head.appendChild(s); }
    s.textContent = JSON.stringify({
      "@context": "https://schema.org", "@type": "RealEstateListing", name: l.title.fr, url: location.href,
      image: l.photos.slice(0, 6).map((p) => photo(p)), description: l.description.join(" ").slice(0, 500),
      offers: l.price ? { "@type": "Offer", price: l.price, priceCurrency: "TND", availability: isAvailable(l) ? "https://schema.org/InStock" : "https://schema.org/SoldOut" } : undefined,
      address: { "@type": "PostalAddress", addressLocality: "Hammamet", addressRegion: "Nabeul", addressCountry: "TN" },
      provider: { "@type": "RealEstateAgent", name: "Green Immobilier", telephone: AGENCY.mobile }
    });
  }

  /* ---------------- Formulaire de contact réutilisable ---------------- */
  function formHTML(prefix, o) {
    const opt = o || {};
    return `<div>
      <form class="form" id="${prefix}-form">
        ${opt.subject ? `<div class="form-field"><label for="${prefix}-subject">${t("form.subject")}</label>
          <select class="select" id="${prefix}-subject" name="subject">${Object.entries(t("contact.subjects")).map(([k, v]) => `<option value="${esc(v)}">${v}</option>`).join("")}</select></div>` : ""}
        <div class="form-field"><label for="${prefix}-name">${t("form.name")} *</label><input class="input" id="${prefix}-name" name="name" autocomplete="name" required><span class="err" aria-live="polite"></span></div>
        <div class="form-row">
          <div class="form-field"><label for="${prefix}-phone">${t("form.phone")} *</label><input class="input" id="${prefix}-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" dir="ltr" required><span class="err" aria-live="polite"></span></div>
          <div class="form-field"><label for="${prefix}-email">${t("form.email")}</label><input class="input" id="${prefix}-email" name="email" type="email" autocomplete="email" dir="ltr"><span class="err" aria-live="polite"></span></div>
        </div>
        <div class="form-field"><label for="${prefix}-message">${t("form.message")} *</label><textarea class="textarea" id="${prefix}-message" name="message" required>${esc(opt.message || "")}</textarea><span class="err" aria-live="polite"></span></div>
        <div class="form-field"><label class="check" style="text-transform:none;letter-spacing:0;font-weight:400;font-size:13.5px;color:var(--muted)"><input type="checkbox" name="consent" value="oui" required> ${t("form.consent")}</label><span class="err" aria-live="polite"></span></div>
        <button class="btn btn--block" type="submit">${t("form.send")}${I.arrow}</button>
      </form>
      <div class="form-ok" role="status" aria-live="polite" style="margin-top:16px"></div>
    </div>`;
  }

  /* ====================================================================
     À PROPOS
     ==================================================================== */
  function about() {
    $("#about").innerHTML = `
    <section class="page-hero">
      <div class="container">
        <nav class="breadcrumb" aria-label="Fil d'Ariane"><a href="${href("index.html")}">${t("nav.home")}</a><span aria-hidden="true">/</span><span>${t("nav.about")}</span></nav>
        <h1 class="display">${t("about.title")}</h1>
      </div>
    </section>
    <section class="section">
      <div class="container about-split">
        <div>
          <p class="lead reveal" style="font-family:var(--f-display);font-size:clamp(24px,2.4vw,32px);line-height:1.35;color:var(--ink)">${t("about.lead")}</p>
          <p class="lead reveal" style="margin-top:24px">${t("about.lead2")}</p>
          <div class="btn-row reveal" style="margin-top:36px"><a class="btn" href="${href("biens.html")}">${t("nav.properties")}${I.arrow}</a><a class="btn btn--ghost" href="${href("contact.html")}">${t("nav.contact")}</a></div>
        </div>
        <div class="about-media img-reveal"><img src="${imgOf("140599", 0)}" alt="" loading="lazy"></div>
      </div>
    </section>
    <section class="section section--sand">
      <div class="container">
        <div class="section-head"><span class="eyebrow reveal">Green Immobilier</span><h2 class="h2 reveal">${t("about.valuesTitle")}</h2></div>
        <ul class="values" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));column-gap:48px;margin:0">
          ${[1, 2, 3, 4, 5].map((k) => `<li class="reveal" style="--d:${(k % 3) * 80}ms"><span class="n">0${k}</span><div><b>${t("about.v" + k + "t")}</b><p>${t("about.v" + k + "d")}</p></div></li>`).join("")}
        </ul>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="section-head"><h2 class="h2 reveal">${t("about.servicesTitle")}</h2></div>
        <div class="services" style="margin-top:0">
          ${[["vente", "s1"], ["location", "s2"], ["vacances", "s3"]].map(([k, s], i) => `
            <div class="service reveal" style="--d:${i * 100}ms"><span class="service-num">0${i + 1}</span><h3>${t("home." + s + "t")}</h3><p>${t("home." + s + "d")}</p>
            <a class="link-arrow" href="${href("biens.html?t=" + k)}">${t("card.discover")}${I.arrow}</a></div>`).join("")}
        </div>
      </div>
    </section>
    <section class="section section--dark">
      <div class="container about-split">
        <blockquote class="quote reveal">« ${t("about.quote")} »<cite>— ${t("about.quoteSrc")} · Instagram</cite></blockquote>
        <div class="about-media img-reveal" style="aspect-ratio:4/3"><img src="${imgOf("139356", 0)}" alt="" loading="lazy"></div>
      </div>
    </section>`;
  }

  /* ====================================================================
     CONTACT
     ==================================================================== */
  function contact() {
    const mapSrc = `https://maps.google.com/maps?q=${AGENCY.lat},${AGENCY.lng}&z=15&hl=${GI.lang}&output=embed`;
    $("#contact").innerHTML = `
    <section class="page-hero">
      <div class="container">
        <nav class="breadcrumb" aria-label="Fil d'Ariane"><a href="${href("index.html")}">${t("nav.home")}</a><span aria-hidden="true">/</span><span>${t("nav.contact")}</span></nav>
        <h1 class="display">${t("contact.title")}</h1>
        <p class="lead">${t("contact.lead")}</p>
      </div>
    </section>
    <section class="section">
      <div class="container contact-grid">
        <div>
          <ul class="contact-list">
            <li class="reveal">${I.pin}<div><span class="label">${t("contact.address")}</span><span class="val">Green Immobilier<br>${AGENCY.address}</span>
              <a class="link-arrow" style="font-family:var(--f-body);font-size:12px;margin-top:10px;display:inline-flex" href="${AGENCY.mapsUrl}" target="_blank" rel="noopener">${t("contact.openMaps")}${I.arrow}</a></div></li>
            <li class="reveal">${I.wa}<div><span class="label">${t("contact.mobile")}</span><a href="${telLink()}" dir="ltr">${AGENCY.mobile}</a>
              <a class="link-arrow" style="font-family:var(--f-body);font-size:12px;margin-top:10px;display:inline-flex" href="${waLink()}" target="_blank" rel="noopener">WhatsApp${I.arrow}</a></div></li>
            <li class="reveal">${I.phone}<div><span class="label">${t("contact.landline")}</span><a href="${telLink(AGENCY.landlineRaw)}" dir="ltr">${AGENCY.landline}</a></div></li>
            <li class="reveal">${I.mail}<div><span class="label">${t("contact.email")}</span><a href="mailto:${AGENCY.email}" style="font-size:21px;word-break:break-all">${AGENCY.email}</a></div></li>
            <li class="reveal">${I.ig}<div><span class="label">${t("contact.social")}</span><a href="${AGENCY.instagram}" target="_blank" rel="noopener">@green_immobilier</a><a href="${AGENCY.facebook}" target="_blank" rel="noopener" style="font-size:19px">Facebook — Green Immobilière</a></div></li>
          </ul>
        </div>
        <div class="panel reveal">
          <h2>${t("contact.formTitle")}</h2>
          ${formHTML("contact", { subject: true })}
        </div>
      </div>
    </section>
    <div class="map-full"><iframe title="Green Immobilier — ${AGENCY.address}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="${mapSrc}"></iframe></div>`;
    GI.initForm($("#contact-form"), {
      subject: (d) => d.subject,
      message: (d) => `${d.subject}\n\n${d.message}\n\n— ${d.name}\n${d.phone}${d.email ? "\n" + d.email : ""}`
    });
  }

  /* ====================================================================
     DÉPOSER UNE ANNONCE
     ==================================================================== */
  function deposit() {
    $("#deposit").innerHTML = `
    <section class="page-hero">
      <div class="container">
        <nav class="breadcrumb" aria-label="Fil d'Ariane"><a href="${href("index.html")}">${t("nav.home")}</a><span aria-hidden="true">/</span><span>${t("deposit.title")}</span></nav>
        <h1 class="display">${t("deposit.title")}</h1>
        <p class="lead">${t("deposit.lead")}</p>
      </div>
    </section>
    <section class="section">
      <div class="container contact-grid">
        <div>
          <h2 class="h3 reveal" style="margin-bottom:20px">${t("deposit.steps")}</h2>
          <ol class="steps reveal"><li>${t("deposit.st1")}</li><li>${t("deposit.st2")}</li><li>${t("deposit.st3")}</li></ol>
          <div class="about-media img-reveal" style="aspect-ratio:4/3;margin-top:36px"><img src="${imgOf("141001", 2)}" alt="" loading="lazy"></div>
          <div class="btn-row" style="margin-top:28px"><a class="btn btn--wa" target="_blank" rel="noopener" href="${waLink()}">${I.wa}WhatsApp</a><a class="btn btn--ghost" href="${telLink()}">${I.phone}<span dir="ltr">${AGENCY.mobile}</span></a></div>
        </div>
        <div class="panel reveal">
          <form class="form" id="deposit-form">
            <h2 style="margin-bottom:6px">${t("deposit.propertyTitle")}</h2>
            <div class="form-field"><span class="label" style="font-size:12px;font-weight:600;letter-spacing:.1em;text-transform:uppercase">${t("deposit.transaction")}</span>
              <div class="radio-cards">${[["sell", "Vente"], ["rent", "Location annuelle"], ["holiday", "Location vacances"]].map(([k, v], i) => `<label><input type="radio" name="projet" value="${v}" ${i ? "" : "checked"}><span>${t("deposit." + k)}</span></label>`).join("")}</div></div>
            <div class="form-row">
              <div class="form-field"><label for="d-type">${t("deposit.type")} *</label><select class="select" id="d-type" name="type" required>${["villa", "appartement", "maison", "terrain", "commerce"].map((k) => `<option value="${t("type." + k)}">${t("type." + k)}</option>`).join("")}</select></div>
              <div class="form-field"><label for="d-loc">${t("deposit.location")} *</label><input class="input" id="d-loc" name="localisation" required><span class="err"></span></div>
            </div>
            <div class="form-row">
              <div class="form-field"><label for="d-surf">${t("deposit.surface")}</label><input class="input" id="d-surf" name="surface" type="number" min="0" inputmode="numeric"></div>
              <div class="form-field"><label for="d-rooms">${t("deposit.rooms")}</label><input class="input" id="d-rooms" name="chambres" type="number" min="0" inputmode="numeric"></div>
            </div>
            <div class="form-field"><label for="d-price">${t("deposit.price")}</label><input class="input" id="d-price" name="prix" type="number" min="0" inputmode="numeric"></div>
            <div class="form-field"><label for="d-details">${t("deposit.details")}</label><textarea class="textarea" id="d-details" name="description"></textarea></div>
            <h2 style="margin:22px 0 6px">${t("deposit.ownerTitle")}</h2>
            <div class="form-field"><label for="d-name">${t("form.name")} *</label><input class="input" id="d-name" name="name" autocomplete="name" required><span class="err"></span></div>
            <div class="form-row">
              <div class="form-field"><label for="d-phone">${t("form.phone")} *</label><input class="input" id="d-phone" name="phone" type="tel" autocomplete="tel" dir="ltr" required><span class="err"></span></div>
              <div class="form-field"><label for="d-email">${t("form.email")}</label><input class="input" id="d-email" name="email" type="email" autocomplete="email" dir="ltr"><span class="err"></span></div>
            </div>
            <div class="form-field"><label class="check" style="text-transform:none;letter-spacing:0;font-weight:400;font-size:13.5px;color:var(--muted)"><input type="checkbox" name="consent" value="oui" required> ${t("form.consent")}</label><span class="err"></span></div>
            <button class="btn btn--block" type="submit">${t("deposit.send")}${I.arrow}</button>
          </form>
          <div class="form-ok" role="status" aria-live="polite" style="margin-top:16px"></div>
        </div>
      </div>
    </section>`;
    GI.initForm($("#deposit-form"), {
      subject: (d) => `Nouvelle annonce — ${d.projet} — ${d.type}`,
      message: (d) => `Bonjour Green Immobilier, je souhaite confier mon bien à l'agence.\n\nProjet : ${d.projet}\nType : ${d.type}\nLocalisation : ${d.localisation}` +
        (d.surface ? `\nSurface : ${d.surface} m²` : "") + (d.chambres ? `\nChambres : ${d.chambres}` : "") + (d.prix ? `\nPrix souhaité : ${d.prix} DT` : "") +
        (d.description ? `\n\n${d.description}` : "") + `\n\n— ${d.name}\n${d.phone}${d.email ? "\n" + d.email : ""}`
    });
  }

  const PAGES = { home, catalogue, property, about, contact, deposit };
  GI.page = PAGES[document.body.dataset.page] || null;
})();
